import { MessageTemplate } from './types';
import { MessageLibraryService } from './messageLibrary';
import { NotificationScheduler } from './notificationScheduler';
import { UserPreferenceManager } from './userPreferenceManager';
import { GuidanceEngine } from '../engines/guidanceEngine';
import { ProgressEngine } from '../engines/progressEngine';

export const TriggerSystem = {
  async evaluateAndTriggerTriggers(): Promise<string[]> {
    const triggeredIds: string[] = [];
    const prefs = UserPreferenceManager.getPreferences();

    if (!prefs.enabled) return triggeredIds;

    // Check if user is struggling -> trigger recovery reminder
    const isStruggling = GuidanceEngine.isUserStruggling();
    if (isStruggling) {
      const msg = MessageLibraryService.getMessageByCategory('recovery');
      if (msg) {
        const id = await NotificationScheduler.scheduleLocalNotification(msg, 10);
        if (id) triggeredIds.push(id);
      }
    }

    // Check completion rate -> if 100%, trigger congratulations
    const completionRate = ProgressEngine.calculateDailyCompletionRate();
    if (completionRate === 100) {
      const msg = MessageLibraryService.getMessageByCategory('congratulations');
      if (msg) {
        const id = await NotificationScheduler.scheduleLocalNotification(msg, 5);
        if (id) triggeredIds.push(id);
      }
    }

    return triggeredIds;
  }
};
