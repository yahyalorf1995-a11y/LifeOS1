import { NotificationPreferences, NotificationCategory } from './types';
import { SettingRepo } from '../database/repositories/settingRepo';

const PREFS_KEY = 'notification_preferences_json';

const DEFAULT_PREFERENCES: NotificationPreferences = {
  enabled: true,
  mutedCategories: [],
  preferredMorningTime: '07:30',
  preferredEveningTime: '21:00',
  maxPerDay: 5
};

export const UserPreferenceManager = {
  getPreferences(): NotificationPreferences {
    try {
      const stored = SettingRepo.get(PREFS_KEY);
      if (stored) {
        return JSON.parse(stored) as NotificationPreferences;
      }
    } catch {
      // fallback
    }
    return DEFAULT_PREFERENCES;
  },

  savePreferences(prefs: NotificationPreferences): void {
    SettingRepo.set(PREFS_KEY, JSON.stringify(prefs));
  },

  isCategoryMuted(category: NotificationCategory): boolean {
    const prefs = this.getPreferences();
    if (!prefs.enabled) return true;
    if (prefs.pausedUntil && new Date(prefs.pausedUntil) > new Date()) return true;
    return prefs.mutedCategories.includes(category);
  },

  toggleMuteCategory(category: NotificationCategory): void {
    const prefs = this.getPreferences();
    const index = prefs.mutedCategories.indexOf(category);
    if (index >= 0) {
      prefs.mutedCategories.splice(index, 1);
    } else {
      prefs.mutedCategories.push(category);
    }
    this.savePreferences(prefs);
  },

  pauseAll(hours: number): void {
    const prefs = this.getPreferences();
    const pauseDate = new Date();
    pauseDate.setHours(pauseDate.getHours() + hours);
    prefs.pausedUntil = pauseDate.toISOString();
    this.savePreferences(prefs);
  }
};
