import { initDatabase, getDatabase } from '../database/db';
import { CoachEngine } from '../engines/coachEngine';
import { UserPreferenceManager } from './userPreferenceManager';
import { SmartNotificationEngine } from './smartNotificationEngine';
import { MessageLibraryService } from './messageLibrary';

describe('Personal Coach & Smart Notifications System', () => {
  beforeEach(() => {
    initDatabase();
    const db = getDatabase();
    db.execSync('DELETE FROM settings;');
    db.execSync('DELETE FROM tasks;');
    db.execSync('DELETE FROM goals;');
  });

  it('Personal Coach generates contextual coaching data', () => {
    const coaching = CoachEngine.getDailyCoaching();
    expect(coaching.greeting).toBeDefined();
    expect(coaching.longTermGoalReminder).toBeDefined();
    expect(coaching.motivationAdvice).toBeDefined();
  });

  it('User Preference Manager manages notification settings', () => {
    const prefs = UserPreferenceManager.getPreferences();
    expect(prefs.enabled).toBe(true);

    UserPreferenceManager.toggleMuteCategory('habit');
    expect(UserPreferenceManager.isCategoryMuted('habit')).toBe(true);

    UserPreferenceManager.toggleMuteCategory('habit');
    expect(UserPreferenceManager.isCategoryMuted('habit')).toBe(false);
  });

  it('Message Library supports retrieval and categories', () => {
    const msg = MessageLibraryService.getMessageByCategory('morning');
    expect(msg).toBeDefined();
    expect(msg?.title).toContain('صباح الخير');
  });

  it('Smart Notification Engine executes evaluation successfully', async () => {
    const triggered = await SmartNotificationEngine.runSmartEvaluation();
    expect(Array.isArray(triggered)).toBe(true);
  });
});
