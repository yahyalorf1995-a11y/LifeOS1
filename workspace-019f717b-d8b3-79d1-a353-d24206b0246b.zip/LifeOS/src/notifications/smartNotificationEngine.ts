import { TriggerSystem } from './triggerSystem';
import { NotificationScheduler } from './notificationScheduler';
import { MessageLibraryService } from './messageLibrary';
import { NotificationCategory } from './types';

export const SmartNotificationEngine = {
  async runSmartEvaluation(): Promise<string[]> {
    return await TriggerSystem.evaluateAndTriggerTriggers();
  },

  async sendImmediateNotification(category: NotificationCategory): Promise<string | null> {
    const msg = MessageLibraryService.getMessageByCategory(category);
    if (!msg) return null;
    return await NotificationScheduler.scheduleLocalNotification(msg, 1);
  }
};
