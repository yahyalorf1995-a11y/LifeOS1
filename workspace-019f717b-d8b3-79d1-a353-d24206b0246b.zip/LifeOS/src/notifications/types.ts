export type NotificationCategory =
  | 'morning'
  | 'habit'
  | 'goal'
  | 'workout'
  | 'reading'
  | 'prayer'
  | 'quran'
  | 'sleep'
  | 'review'
  | 'motivation'
  | 'recovery'
  | 'congratulations'
  | 'weekly_summary'
  | 'monthly_summary';

export type NotificationTone = 'friendly' | 'motivational' | 'calm' | 'urgent' | 'celebratory';

export interface MessageTemplate {
  id: string;
  category: NotificationCategory;
  title: string;
  body: string;
  tone: NotificationTone;
  triggerCondition: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
}

export interface NotificationPreferences {
  enabled: boolean;
  pausedUntil?: string;
  mutedCategories: NotificationCategory[];
  preferredMorningTime: string; // e.g. "07:00"
  preferredEveningTime: string; // e.g. "21:00"
  maxPerDay: number;
}
