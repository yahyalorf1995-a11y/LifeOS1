import { MessageTemplate, NotificationCategory } from './types';

export const MessageLibrary: MessageTemplate[] = [
  {
    id: 'msg_morning_1',
    category: 'morning',
    title: 'صباح الخير يا بطل! 🌅',
    body: 'يوم جديد وفُرَص جديدة لتحقيق أهدافك. إليك أهم مهمة اليوم في انتظارك.',
    tone: 'motivational',
    triggerCondition: 'morning_greeting',
    priority: 'high'
  },
  {
    id: 'msg_habit_1',
    category: 'habit',
    title: 'وقت العادة اليومية 🎯',
    body: 'الاستمرارية تصنع المعجزات. حافظ على سلسلتك اليومية الآن!',
    tone: 'friendly',
    triggerCondition: 'habit_due',
    priority: 'medium'
  },
  {
    id: 'msg_goal_1',
    category: 'goal',
    title: 'خطوة أقرب لهدفك 🏔️',
    body: 'تذكر أهدافك طويل الأمد، كل إنجاز صغير اليوم يقربك قمة الجبل.',
    tone: 'motivational',
    triggerCondition: 'goal_progress',
    priority: 'medium'
  },
  {
    id: 'msg_recovery_1',
    category: 'recovery',
    title: 'خطوة صغيرة للعودة 🌱',
    body: 'لا تقلق من التراجع المؤقت. ابدأ بخطوة صغيرة اليوم وسيعود زخمك تدريجيًا.',
    tone: 'calm',
    triggerCondition: 'user_struggling',
    priority: 'urgent'
  },
  {
    id: 'msg_congrats_1',
    category: 'congratulations',
    title: 'رائع جداً! 🎉',
    body: 'أنهيت مهامك بنجاح اليوم! فخور جداً بالتزامك.',
    tone: 'celebratory',
    triggerCondition: 'all_tasks_completed',
    priority: 'high'
  },
  {
    id: 'msg_review_1',
    category: 'review',
    title: 'مراجعة نهاية اليوم 🌙',
    body: 'خذ دقيقة لتلخص إنجازاتك وتستعد لغدٍ أفضل.',
    tone: 'calm',
    triggerCondition: 'end_of_day',
    priority: 'low'
  },
  {
    id: 'msg_sleep_1',
    category: 'sleep',
    title: 'وقت الاستعداد للنوم 🛌',
    body: 'النوم الجيد هو وقود إنتاجيتك غدًا. جهز نفسك للراحة.',
    tone: 'calm',
    triggerCondition: 'bedtime',
    priority: 'medium'
  }
];

export const MessageLibraryService = {
  getMessageByCategory(category: NotificationCategory): MessageTemplate | undefined {
    return MessageLibrary.find(m => m.category === category);
  },

  getAllMessages(): MessageTemplate[] {
    return MessageLibrary;
  },

  addMessage(template: MessageTemplate): void {
    MessageLibrary.push(template);
  }
};
