import * as Notifications from 'expo-notifications';
import { MessageTemplate } from './types';
import { UserPreferenceManager } from './userPreferenceManager';

export const NotificationScheduler = {
  async scheduleLocalNotification(message: MessageTemplate, triggerSeconds: number = 60): Promise<string | null> {
    if (UserPreferenceManager.isCategoryMuted(message.category)) {
      return null;
    }

    try {
      const identifier = await Notifications.scheduleNotificationAsync({
        content: {
          title: message.title,
          body: message.body,
          data: { category: message.category, tone: message.tone },
        },
        trigger: {
          type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
          seconds: triggerSeconds,
          repeats: false
        },
      });

      return identifier;
    } catch (error) {
      // Fallback for environments where native notifications are not available (e.g. headless tests)
      console.log('Native notification scheduling simulated:', message.title);
      return 'simulated_id_' + Date.now();
    }
  },

  async cancelAllScheduled(): Promise<void> {
    try {
      await Notifications.cancelAllScheduledNotificationsAsync();
    } catch {
      // Ignore in test environments
    }
  }
};
