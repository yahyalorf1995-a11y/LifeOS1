import * as SQLite from 'expo-sqlite';
import { CREATE_TABLES_SQL } from './schema';
import { seedLibraryContent } from '../library/seedContent';

let dbInstance: SQLite.SQLiteDatabase | null = null;

export function getDatabase(): SQLite.SQLiteDatabase {
  if (!dbInstance) {
    dbInstance = SQLite.openDatabaseSync('lifeos.db');
  }
  return dbInstance;
}

export function initDatabase(): void {
  const db = getDatabase();
  try {
    db.execSync(CREATE_TABLES_SQL);
    seedLibraryContent();
    console.log('Database initialized and content seeded successfully.');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}
