export const CREATE_TABLES_SQL = `
-- Enable foreign keys
PRAGMA foreign_keys = ON;

-- 1. User Table
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT,
  avatar_url TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- 2. Life Areas Table
CREATE TABLE IF NOT EXISTS life_areas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  color TEXT,
  icon TEXT,
  target_score REAL DEFAULT 0.0,
  created_at TEXT NOT NULL
);

-- 3. Goals Table
CREATE TABLE IF NOT EXISTS goals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  life_area_id INTEGER,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  target_date TEXT,
  progress REAL DEFAULT 0.0,
  created_at TEXT NOT NULL,
  FOREIGN KEY (life_area_id) REFERENCES life_areas(id) ON DELETE CASCADE
);

-- 4. Protocols Table
CREATE TABLE IF NOT EXISTS protocols (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT,
  is_active INTEGER DEFAULT 1,
  created_at TEXT NOT NULL
);

-- 5. Habits Table
CREATE TABLE IF NOT EXISTS habits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  life_area_id INTEGER,
  goal_id INTEGER,
  title TEXT NOT NULL,
  description TEXT,
  frequency TEXT NOT NULL DEFAULT 'daily',
  target_value INTEGER DEFAULT 1,
  created_at TEXT NOT NULL,
  FOREIGN KEY (life_area_id) REFERENCES life_areas(id) ON DELETE SET NULL,
  FOREIGN KEY (goal_id) REFERENCES goals(id) ON DELETE SET NULL
);

-- 6. Routines Table
CREATE TABLE IF NOT EXISTS routines (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  time_of_day TEXT,
  is_active INTEGER DEFAULT 1,
  created_at TEXT NOT NULL
);

-- 7. Tasks Table
CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  goal_id INTEGER,
  habit_id INTEGER,
  routine_id INTEGER,
  title TEXT NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  priority TEXT NOT NULL DEFAULT 'medium',
  due_date TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (goal_id) REFERENCES goals(id) ON DELETE CASCADE,
  FOREIGN KEY (habit_id) REFERENCES habits(id) ON DELETE SET NULL,
  FOREIGN KEY (routine_id) REFERENCES routines(id) ON DELETE SET NULL
);

-- 8. Daily Plans Table
CREATE TABLE IF NOT EXISTS daily_plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT NOT NULL UNIQUE,
  energy_level INTEGER,
  focus_score INTEGER,
  notes TEXT,
  created_at TEXT NOT NULL
);

-- 9. Daily Sessions Table
CREATE TABLE IF NOT EXISTS daily_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  daily_plan_id INTEGER,
  habit_id INTEGER,
  task_id INTEGER,
  session_type TEXT NOT NULL,
  duration_minutes INTEGER DEFAULT 0,
  completed INTEGER DEFAULT 0,
  notes TEXT,
  timestamp TEXT NOT NULL,
  FOREIGN KEY (daily_plan_id) REFERENCES daily_plans(id) ON DELETE CASCADE,
  FOREIGN KEY (habit_id) REFERENCES habits(id) ON DELETE SET NULL,
  FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE SET NULL
);

-- 10. Reviews Table
CREATE TABLE IF NOT EXISTS reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  review_type TEXT NOT NULL,
  period_key TEXT NOT NULL,
  wins TEXT,
  challenges TEXT,
  lessons TEXT,
  rating INTEGER,
  created_at TEXT NOT NULL
);

-- 11. Metrics Table
CREATE TABLE IF NOT EXISTS metrics (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  metric_name TEXT NOT NULL,
  metric_value REAL NOT NULL,
  unit TEXT,
  recorded_date TEXT NOT NULL,
  notes TEXT
);

-- 12. Suggestions Table
CREATE TABLE IF NOT EXISTS suggestions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category TEXT NOT NULL,
  content TEXT NOT NULL,
  is_read INTEGER DEFAULT 0,
  action_url TEXT,
  created_at TEXT NOT NULL
);

-- 13. Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  trigger_time TEXT NOT NULL,
  is_sent INTEGER DEFAULT 0,
  created_at TEXT NOT NULL
);

-- 14. Achievements Table
CREATE TABLE IF NOT EXISTS achievements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT,
  unlocked_at TEXT NOT NULL
);

-- 15. History Table
CREATE TABLE IF NOT EXISTS history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type TEXT NOT NULL,
  entity_id INTEGER,
  action TEXT NOT NULL,
  details TEXT,
  timestamp TEXT NOT NULL
);

-- 16. Core Library Items Table (Enhanced for EO 004)
CREATE TABLE IF NOT EXISTS library_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL,
  life_area TEXT NOT NULL,
  difficulty TEXT NOT NULL,
  estimated_time INTEGER NOT NULL DEFAULT 0,
  energy_level TEXT NOT NULL,
  priority TEXT NOT NULL,
  location TEXT NOT NULL,
  tags TEXT NOT NULL, -- JSON array string
  related_goals TEXT, -- JSON array string
  related_habits TEXT, -- JSON array string
  related_protocols TEXT, -- JSON array string
  created_at TEXT NOT NULL
);

-- 17. Settings Table
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- Indexes for Performance
CREATE INDEX IF NOT EXISTS idx_goals_life_area ON goals(life_area_id);
CREATE INDEX IF NOT EXISTS idx_habits_life_area ON habits(life_area_id);
CREATE INDEX IF NOT EXISTS idx_habits_goal ON habits(goal_id);
CREATE INDEX IF NOT EXISTS idx_tasks_goal ON tasks(goal_id);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_due_date ON tasks(due_date);
CREATE INDEX IF NOT EXISTS idx_daily_sessions_plan ON daily_sessions(daily_plan_id);
CREATE INDEX IF NOT EXISTS idx_daily_plans_date ON daily_plans(date);
CREATE INDEX IF NOT EXISTS idx_reviews_type_period ON reviews(review_type, period_key);
CREATE INDEX IF NOT EXISTS idx_metrics_name_date ON metrics(metric_name, recorded_date);
CREATE INDEX IF NOT EXISTS idx_library_items_type ON library_items(type);
CREATE INDEX IF NOT EXISTS idx_library_items_life_area ON library_items(life_area);
CREATE INDEX IF NOT EXISTS idx_library_items_category ON library_items(category);
`;
