import { getDatabase } from '../db';

export interface LibraryItem {
  id?: number;
  title: string;
  author?: string;
  category: string;
  summary?: string;
  notes?: string;
  rating?: number;
  created_at: string;
}

export const LibraryRepo = {
  create(l: Omit<LibraryItem, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync('INSERT INTO library (title, author, category, summary, notes, rating, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
    try {
      const res = stmt.executeSync(l.title, l.author || null, l.category, l.summary || null, l.notes || null, l.rating ?? null, l.created_at);
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },
  findById(id: number): LibraryItem | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM library WHERE id = ?');
    try {
      return (stmt.executeSync(id).getAllSync() as LibraryItem[])[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },
  findAll(): LibraryItem[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM library') as LibraryItem[];
  },
  update(id: number, l: Partial<LibraryItem>): void {
    const db = getDatabase();
    const curr = this.findById(id);
    if (!curr) return;
    const stmt = db.prepareSync('UPDATE library SET title = ?, author = ?, category = ?, summary = ?, notes = ?, rating = ? WHERE id = ?');
    try {
      stmt.executeSync(l.title ?? curr.title, l.author ?? curr.author ?? null, l.category ?? curr.category, l.summary ?? curr.summary ?? null, l.notes ?? curr.notes ?? null, l.rating ?? curr.rating ?? null, id);
    } finally {
      stmt.finalizeSync();
    }
  },
  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM library WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};
