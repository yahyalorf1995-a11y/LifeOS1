import { getDatabase } from '../db';

export interface Achievement {
  id?: number;
  title: string;
  description?: string;
  category?: string;
  unlocked_at: string;
}

export const AchievementRepo = {
  create(a: Omit<Achievement, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync('INSERT INTO achievements (title, description, category, unlocked_at) VALUES (?, ?, ?, ?)');
    try {
      const res = stmt.executeSync(a.title, a.description || null, a.category || null, a.unlocked_at);
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },
  findById(id: number): Achievement | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM achievements WHERE id = ?');
    try {
      return (stmt.executeSync(id).getAllSync() as Achievement[])[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },
  findAll(): Achievement[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM achievements') as Achievement[];
  },
  update(id: number, a: Partial<Achievement>): void {
    const db = getDatabase();
    const curr = this.findById(id);
    if (!curr) return;
    const stmt = db.prepareSync('UPDATE achievements SET title = ?, description = ?, category = ?, unlocked_at = ? WHERE id = ?');
    try {
      stmt.executeSync(a.title ?? curr.title, a.description ?? curr.description ?? null, a.category ?? curr.category ?? null, a.unlocked_at ?? curr.unlocked_at, id);
    } finally {
      stmt.finalizeSync();
    }
  },
  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM achievements WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};
