import { getDatabase } from '../db';

export interface HistoryRecord {
  id?: number;
  entity_type: string;
  entity_id?: number;
  action: string;
  details?: string;
  timestamp: string;
}

export const HistoryRepo = {
  create(h: Omit<HistoryRecord, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync('INSERT INTO history (entity_type, entity_id, action, details, timestamp) VALUES (?, ?, ?, ?, ?)');
    try {
      const res = stmt.executeSync(h.entity_type, h.entity_id ?? null, h.action, h.details || null, h.timestamp);
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },
  findById(id: number): HistoryRecord | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM history WHERE id = ?');
    try {
      return (stmt.executeSync(id).getAllSync() as HistoryRecord[])[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },
  findAll(): HistoryRecord[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM history') as HistoryRecord[];
  },
  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM history WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};
