import { getDatabase } from '../db';

export interface Setting {
  key: string;
  value: string;
  updated_at: string;
}

export const SettingRepo = {
  set(key: string, value: string): void {
    const db = getDatabase();
    const updated_at = new Date().toISOString();
    const stmt = db.prepareSync(
      'INSERT INTO settings (key, value, updated_at) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value = ?, updated_at = ?'
    );
    try {
      stmt.executeSync(key, value, updated_at, value, updated_at);
    } finally {
      stmt.finalizeSync();
    }
  },

  get(key: string): string | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT value FROM settings WHERE key = ?');
    try {
      const rows = stmt.executeSync(key).getAllSync() as { value: string }[];
      return rows.length > 0 ? rows[0].value : null;
    } finally {
      stmt.finalizeSync();
    }
  },

  findAll(): Setting[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM settings') as Setting[];
  },

  delete(key: string): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM settings WHERE key = ?');
    try {
      stmt.executeSync(key);
    } finally {
      stmt.finalizeSync();
    }
  }
};
