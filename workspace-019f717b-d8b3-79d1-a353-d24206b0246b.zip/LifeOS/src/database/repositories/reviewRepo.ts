import { getDatabase } from '../db';

export interface Review {
  id?: number;
  review_type: string;
  period_key: string;
  wins?: string;
  challenges?: string;
  lessons?: string;
  rating?: number;
  created_at: string;
}

export const ReviewRepo = {
  create(r: Omit<Review, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync('INSERT INTO reviews (review_type, period_key, wins, challenges, lessons, rating, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
    try {
      const res = stmt.executeSync(r.review_type, r.period_key, r.wins || null, r.challenges || null, r.lessons || null, r.rating ?? null, r.created_at);
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },
  findById(id: number): Review | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM reviews WHERE id = ?');
    try {
      return (stmt.executeSync(id).getAllSync() as Review[])[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },
  findAll(): Review[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM reviews') as Review[];
  },
  update(id: number, r: Partial<Review>): void {
    const db = getDatabase();
    const curr = this.findById(id);
    if (!curr) return;
    const stmt = db.prepareSync('UPDATE reviews SET review_type = ?, period_key = ?, wins = ?, challenges = ?, lessons = ?, rating = ? WHERE id = ?');
    try {
      stmt.executeSync(r.review_type ?? curr.review_type, r.period_key ?? curr.period_key, r.wins ?? curr.wins ?? null, r.challenges ?? curr.challenges ?? null, r.lessons ?? curr.lessons ?? null, r.rating ?? curr.rating ?? null, id);
    } finally {
      stmt.finalizeSync();
    }
  },
  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM reviews WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};
