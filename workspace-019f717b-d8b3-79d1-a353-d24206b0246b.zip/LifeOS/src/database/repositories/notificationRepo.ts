import { getDatabase } from '../db';

export interface NotificationRecord {
  id?: number;
  title: string;
  body: string;
  trigger_time: string;
  is_sent?: number;
  created_at: string;
}

export const NotificationRepo = {
  create(n: Omit<NotificationRecord, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync('INSERT INTO notifications (title, body, trigger_time, is_sent, created_at) VALUES (?, ?, ?, ?, ?)');
    try {
      const res = stmt.executeSync(n.title, n.body, n.trigger_time, n.is_sent ?? 0, n.created_at);
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },
  findById(id: number): NotificationRecord | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM notifications WHERE id = ?');
    try {
      return (stmt.executeSync(id).getAllSync() as NotificationRecord[])[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },
  findAll(): NotificationRecord[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM notifications') as NotificationRecord[];
  },
  update(id: number, n: Partial<NotificationRecord>): void {
    const db = getDatabase();
    const curr = this.findById(id);
    if (!curr) return;
    const stmt = db.prepareSync('UPDATE notifications SET title = ?, body = ?, trigger_time = ?, is_sent = ? WHERE id = ?');
    try {
      stmt.executeSync(n.title ?? curr.title, n.body ?? curr.body, n.trigger_time ?? curr.trigger_time, n.is_sent ?? curr.is_sent ?? 0, id);
    } finally {
      stmt.finalizeSync();
    }
  },
  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM notifications WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};
