import { getDatabase } from '../db';

export interface DailySession {
  id?: number;
  daily_plan_id?: number;
  habit_id?: number;
  task_id?: number;
  session_type: string;
  duration_minutes?: number;
  completed?: number;
  notes?: string;
  timestamp: string;
}

export const DailySessionRepo = {
  create(s: Omit<DailySession, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync('INSERT INTO daily_sessions (daily_plan_id, habit_id, task_id, session_type, duration_minutes, completed, notes, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    try {
      const res = stmt.executeSync(
        s.daily_plan_id ?? null,
        s.habit_id ?? null,
        s.task_id ?? null,
        s.session_type,
        s.duration_minutes ?? 0,
        s.completed ?? 0,
        s.notes || null,
        s.timestamp
      );
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },
  findById(id: number): DailySession | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM daily_sessions WHERE id = ?');
    try {
      return (stmt.executeSync(id).getAllSync() as DailySession[])[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },
  findAll(): DailySession[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM daily_sessions') as DailySession[];
  },
  update(id: number, s: Partial<DailySession>): void {
    const db = getDatabase();
    const curr = this.findById(id);
    if (!curr) return;
    const stmt = db.prepareSync('UPDATE daily_sessions SET daily_plan_id = ?, habit_id = ?, task_id = ?, session_type = ?, duration_minutes = ?, completed = ?, notes = ? WHERE id = ?');
    try {
      stmt.executeSync(
        s.daily_plan_id ?? curr.daily_plan_id ?? null,
        s.habit_id ?? curr.habit_id ?? null,
        s.task_id ?? curr.task_id ?? null,
        s.session_type ?? curr.session_type,
        s.duration_minutes ?? curr.duration_minutes ?? 0,
        s.completed ?? curr.completed ?? 0,
        s.notes ?? curr.notes ?? null,
        id
      );
    } finally {
      stmt.finalizeSync();
    }
  },
  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM daily_sessions WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};
