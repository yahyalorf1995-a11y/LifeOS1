import { getDatabase } from '../db';

export interface Suggestion {
  id?: number;
  category: string;
  content: string;
  is_read?: number;
  action_url?: string;
  created_at: string;
}

export const SuggestionRepo = {
  create(s: Omit<Suggestion, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync('INSERT INTO suggestions (category, content, is_read, action_url, created_at) VALUES (?, ?, ?, ?, ?)');
    try {
      const res = stmt.executeSync(s.category, s.content, s.is_read ?? 0, s.action_url || null, s.created_at);
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },
  findById(id: number): Suggestion | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM suggestions WHERE id = ?');
    try {
      return (stmt.executeSync(id).getAllSync() as Suggestion[])[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },
  findAll(): Suggestion[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM suggestions') as Suggestion[];
  },
  update(id: number, s: Partial<Suggestion>): void {
    const db = getDatabase();
    const curr = this.findById(id);
    if (!curr) return;
    const stmt = db.prepareSync('UPDATE suggestions SET category = ?, content = ?, is_read = ?, action_url = ? WHERE id = ?');
    try {
      stmt.executeSync(s.category ?? curr.category, s.content ?? curr.content, s.is_read ?? curr.is_read ?? 0, s.action_url ?? curr.action_url ?? null, id);
    } finally {
      stmt.finalizeSync();
    }
  },
  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM suggestions WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};
