import { getDatabase } from '../db';

export interface Routine {
  id?: number;
  title: string;
  description?: string;
  time_of_day?: string;
  is_active?: number;
  created_at: string;
}

export const RoutineRepo = {
  create(r: Omit<Routine, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync('INSERT INTO routines (title, description, time_of_day, is_active, created_at) VALUES (?, ?, ?, ?, ?)');
    try {
      const res = stmt.executeSync(r.title, r.description || null, r.time_of_day || null, r.is_active ?? 1, r.created_at);
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },
  findById(id: number): Routine | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM routines WHERE id = ?');
    try {
      return (stmt.executeSync(id).getAllSync() as Routine[])[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },
  findAll(): Routine[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM routines') as Routine[];
  },
  update(id: number, r: Partial<Routine>): void {
    const db = getDatabase();
    const curr = this.findById(id);
    if (!curr) return;
    const stmt = db.prepareSync('UPDATE routines SET title = ?, description = ?, time_of_day = ?, is_active = ? WHERE id = ?');
    try {
      stmt.executeSync(r.title ?? curr.title, r.description ?? curr.description ?? null, r.time_of_day ?? curr.time_of_day ?? null, r.is_active ?? curr.is_active ?? 1, id);
    } finally {
      stmt.finalizeSync();
    }
  },
  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM routines WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};
