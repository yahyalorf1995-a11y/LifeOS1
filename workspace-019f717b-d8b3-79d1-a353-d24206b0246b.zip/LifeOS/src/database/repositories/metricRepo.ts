import { getDatabase } from '../db';

export interface Metric {
  id?: number;
  metric_name: string;
  metric_value: number;
  unit?: string;
  recorded_date: string;
  notes?: string | null;
}

export const MetricRepo = {
  create(m: Omit<Metric, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync('INSERT INTO metrics (metric_name, metric_value, unit, recorded_date, notes) VALUES (?, ?, ?, ?, ?)');
    try {
      const res = stmt.executeSync(m.metric_name, m.metric_value, m.unit || null, m.recorded_date, m.notes || null);
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },
  findById(id: number): Metric | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM metrics WHERE id = ?');
    try {
      return (stmt.executeSync(id).getAllSync() as Metric[])[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },
  findAll(): Metric[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM metrics') as Metric[];
  },
  update(id: number, m: Partial<Metric>): void {
    const db = getDatabase();
    const curr = this.findById(id);
    if (!curr) return;
    const stmt = db.prepareSync('UPDATE metrics SET metric_name = ?, metric_value = ?, unit = ?, recorded_date = ?, notes = ? WHERE id = ?');
    try {
      stmt.executeSync(m.metric_name ?? curr.metric_name, m.metric_value ?? curr.metric_value, m.unit ?? curr.unit ?? null, m.recorded_date ?? curr.recorded_date, m.notes ?? curr.notes ?? null, id);
    } finally {
      stmt.finalizeSync();
    }
  },
  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM metrics WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};
