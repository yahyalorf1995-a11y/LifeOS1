import { getDatabase } from '../db';

export interface DailyPlan {
  id?: number;
  date: string;
  energy_level?: number;
  focus_score?: number;
  notes?: string;
  created_at: string;
}

export const DailyPlanRepo = {
  create(p: Omit<DailyPlan, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync('INSERT INTO daily_plans (date, energy_level, focus_score, notes, created_at) VALUES (?, ?, ?, ?, ?)');
    try {
      const res = stmt.executeSync(p.date, p.energy_level ?? null, p.focus_score ?? null, p.notes || null, p.created_at);
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },
  findById(id: number): DailyPlan | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM daily_plans WHERE id = ?');
    try {
      return (stmt.executeSync(id).getAllSync() as DailyPlan[])[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },
  findByDate(date: string): DailyPlan | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM daily_plans WHERE date = ?');
    try {
      return (stmt.executeSync(date).getAllSync() as DailyPlan[])[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },
  findAll(): DailyPlan[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM daily_plans') as DailyPlan[];
  },
  update(id: number, p: Partial<DailyPlan>): void {
    const db = getDatabase();
    const curr = this.findById(id);
    if (!curr) return;
    const stmt = db.prepareSync('UPDATE daily_plans SET date = ?, energy_level = ?, focus_score = ?, notes = ? WHERE id = ?');
    try {
      stmt.executeSync(p.date ?? curr.date, p.energy_level ?? curr.energy_level ?? null, p.focus_score ?? curr.focus_score ?? null, p.notes ?? curr.notes ?? null, id);
    } finally {
      stmt.finalizeSync();
    }
  },
  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM daily_plans WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};
