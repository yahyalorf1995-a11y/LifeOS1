import { getDatabase } from '../db';

export interface Task {
  id?: number;
  goal_id?: number;
  habit_id?: number;
  routine_id?: number;
  title: string;
  description?: string;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  due_date?: string;
  created_at: string;
}

export const TaskRepo = {
  create(t: Omit<Task, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync('INSERT INTO tasks (goal_id, habit_id, routine_id, title, description, status, priority, due_date, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    try {
      const res = stmt.executeSync(
        t.goal_id ?? null,
        t.habit_id ?? null,
        t.routine_id ?? null,
        t.title,
        t.description || null,
        t.status || 'pending',
        t.priority || 'medium',
        t.due_date || null,
        t.created_at
      );
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },
  findById(id: number): Task | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM tasks WHERE id = ?');
    try {
      return (stmt.executeSync(id).getAllSync() as Task[])[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },
  findAll(): Task[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM tasks') as Task[];
  },
  update(id: number, t: Partial<Task>): void {
    const db = getDatabase();
    const curr = this.findById(id);
    if (!curr) return;
    const stmt = db.prepareSync('UPDATE tasks SET goal_id = ?, habit_id = ?, routine_id = ?, title = ?, description = ?, status = ?, priority = ?, due_date = ? WHERE id = ?');
    try {
      stmt.executeSync(
        t.goal_id ?? curr.goal_id ?? null,
        t.habit_id ?? curr.habit_id ?? null,
        t.routine_id ?? curr.routine_id ?? null,
        t.title ?? curr.title,
        t.description ?? curr.description ?? null,
        t.status ?? curr.status,
        t.priority ?? curr.priority,
        t.due_date ?? curr.due_date ?? null,
        id
      );
    } finally {
      stmt.finalizeSync();
    }
  },
  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM tasks WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};
