import { getDatabase } from '../db';

export interface Habit {
  id?: number;
  life_area_id?: number;
  goal_id?: number;
  title: string;
  description?: string;
  frequency: string;
  target_value: number;
  created_at: string;
}

export const HabitRepo = {
  create(h: Omit<Habit, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync('INSERT INTO habits (life_area_id, goal_id, title, description, frequency, target_value, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)');
    try {
      const res = stmt.executeSync(h.life_area_id ?? null, h.goal_id ?? null, h.title, h.description || null, h.frequency || 'daily', h.target_value ?? 1, h.created_at);
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },
  findById(id: number): Habit | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM habits WHERE id = ?');
    try {
      return (stmt.executeSync(id).getAllSync() as Habit[])[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },
  findAll(): Habit[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM habits') as Habit[];
  },
  update(id: number, h: Partial<Habit>): void {
    const db = getDatabase();
    const curr = this.findById(id);
    if (!curr) return;
    const stmt = db.prepareSync('UPDATE habits SET life_area_id = ?, goal_id = ?, title = ?, description = ?, frequency = ?, target_value = ? WHERE id = ?');
    try {
      stmt.executeSync(h.life_area_id ?? curr.life_area_id ?? null, h.goal_id ?? curr.goal_id ?? null, h.title ?? curr.title, h.description ?? curr.description ?? null, h.frequency ?? curr.frequency, h.target_value ?? curr.target_value, id);
    } finally {
      stmt.finalizeSync();
    }
  },
  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM habits WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};
