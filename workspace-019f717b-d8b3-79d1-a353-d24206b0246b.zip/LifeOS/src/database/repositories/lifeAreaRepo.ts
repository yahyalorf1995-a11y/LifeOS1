import { getDatabase } from '../db';

export interface LifeArea {
  id?: number;
  name: string;
  description?: string;
  color?: string;
  icon?: string;
  target_score?: number;
  created_at: string;
}

export const LifeAreaRepo = {
  create(area: Omit<LifeArea, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync(
      'INSERT INTO life_areas (name, description, color, icon, target_score, created_at) VALUES (?, ?, ?, ?, ?, ?)'
    );
    try {
      const res = stmt.executeSync(
        area.name,
        area.description || null,
        area.color || null,
        area.icon || null,
        area.target_score ?? 0.0,
        area.created_at
      );
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },

  findById(id: number): LifeArea | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM life_areas WHERE id = ?');
    try {
      const rows = stmt.executeSync(id).getAllSync() as LifeArea[];
      return rows[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },

  findAll(): LifeArea[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM life_areas') as LifeArea[];
  },

  update(id: number, area: Partial<LifeArea>): void {
    const db = getDatabase();
    const current = this.findById(id);
    if (!current) return;

    const stmt = db.prepareSync(
      'UPDATE life_areas SET name = ?, description = ?, color = ?, icon = ?, target_score = ? WHERE id = ?'
    );
    try {
      stmt.executeSync(
        area.name ?? current.name,
        area.description ?? current.description ?? null,
        area.color ?? current.color ?? null,
        area.icon ?? current.icon ?? null,
        area.target_score ?? current.target_score ?? 0.0,
        id
      );
    } finally {
      stmt.finalizeSync();
    }
  },

  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM life_areas WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};
