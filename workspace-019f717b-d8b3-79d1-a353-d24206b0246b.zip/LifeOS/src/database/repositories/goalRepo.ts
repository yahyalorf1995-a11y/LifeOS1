import { getDatabase } from '../db';

export interface Goal {
  id?: number;
  life_area_id?: number;
  title: string;
  description?: string;
  status: 'active' | 'completed' | 'paused' | 'abandoned';
  target_date?: string;
  progress?: number;
  created_at: string;
}

export const GoalRepo = {
  create(goal: Omit<Goal, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync(
      'INSERT INTO goals (life_area_id, title, description, status, target_date, progress, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
    );
    try {
      const res = stmt.executeSync(
        goal.life_area_id ?? null,
        goal.title,
        goal.description || null,
        goal.status || 'active',
        goal.target_date || null,
        goal.progress ?? 0.0,
        goal.created_at
      );
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },

  findById(id: number): Goal | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM goals WHERE id = ?');
    try {
      const rows = stmt.executeSync(id).getAllSync() as Goal[];
      return rows[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },

  findAll(): Goal[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM goals') as Goal[];
  },

  findByLifeArea(lifeAreaId: number): Goal[] {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM goals WHERE life_area_id = ?');
    try {
      return stmt.executeSync(lifeAreaId).getAllSync() as Goal[];
    } finally {
      stmt.finalizeSync();
    }
  },

  update(id: number, goal: Partial<Goal>): void {
    const db = getDatabase();
    const current = this.findById(id);
    if (!current) return;

    const stmt = db.prepareSync(
      'UPDATE goals SET life_area_id = ?, title = ?, description = ?, status = ?, target_date = ?, progress = ? WHERE id = ?'
    );
    try {
      stmt.executeSync(
        goal.life_area_id !== undefined ? goal.life_area_id : (current.life_area_id ?? null),
        goal.title ?? current.title,
        goal.description ?? current.description ?? null,
        goal.status ?? current.status,
        goal.target_date ?? current.target_date ?? null,
        goal.progress ?? current.progress ?? 0.0,
        id
      );
    } finally {
      stmt.finalizeSync();
    }
  },

  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM goals WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};
