import { getDatabase } from '../db';

export interface Protocol {
  id?: number;
  title: string;
  description?: string;
  category?: string;
  is_active?: number;
  created_at: string;
}

export const ProtocolRepo = {
  create(p: Omit<Protocol, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync('INSERT INTO protocols (title, description, category, is_active, created_at) VALUES (?, ?, ?, ?, ?)');
    try {
      const res = stmt.executeSync(p.title, p.description || null, p.category || null, p.is_active ?? 1, p.created_at);
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },
  findById(id: number): Protocol | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM protocols WHERE id = ?');
    try {
      return (stmt.executeSync(id).getAllSync() as Protocol[])[0] || null;
    } finally {
      stmt.finalizeSync();
    }
  },
  findAll(): Protocol[] {
    const db = getDatabase();
    return db.getAllSync('SELECT * FROM protocols') as Protocol[];
  },
  update(id: number, p: Partial<Protocol>): void {
    const db = getDatabase();
    const curr = this.findById(id);
    if (!curr) return;
    const stmt = db.prepareSync('UPDATE protocols SET title = ?, description = ?, category = ?, is_active = ? WHERE id = ?');
    try {
      stmt.executeSync(p.title ?? curr.title, p.description ?? curr.description ?? null, p.category ?? curr.category ?? null, p.is_active ?? curr.is_active ?? 1, id);
    } finally {
      stmt.finalizeSync();
    }
  },
  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM protocols WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};
