import { getDatabase } from '../db';

export interface User {
  id?: number;
  name: string;
  email?: string;
  avatar_url?: string;
  created_at: string;
  updated_at: string;
}

export const UserRepo = {
  create(user: Omit<User, 'id'>): number {
    const db = getDatabase();
    const statement = db.prepareSync(
      'INSERT INTO users (name, email, avatar_url, created_at, updated_at) VALUES (?, ?, ?, ?, ?)'
    );
    try {
      const result = statement.executeSync(
        user.name,
        user.email || null,
        user.avatar_url || null,
        user.created_at,
        user.updated_at
      );
      return result.lastInsertRowId;
    } finally {
      statement.finalizeSync();
    }
  },

  findById(id: number): User | null {
    const db = getDatabase();
    const statement = db.prepareSync('SELECT * FROM users WHERE id = ?');
    try {
      const result = statement.executeSync(id);
      const rows = result.getAllSync() as User[];
      return rows.length > 0 ? rows[0] : null;
    } finally {
      statement.finalizeSync();
    }
  },

  findAll(): User[] {
    const db = getDatabase();
    const result = db.getAllSync('SELECT * FROM users') as User[];
    return result;
  },

  update(id: number, user: Partial<User>): void {
    const db = getDatabase();
    const existing = this.findById(id);
    if (!existing) return;

    const name = user.name !== undefined ? user.name : existing.name;
    const email = user.email !== undefined ? user.email : existing.email;
    const avatar_url = user.avatar_url !== undefined ? user.avatar_url : existing.avatar_url;
    const updated_at = new Date().toISOString();

    const statement = db.prepareSync(
      'UPDATE users SET name = ?, email = ?, avatar_url = ?, updated_at = ? WHERE id = ?'
    );
    try {
      statement.executeSync(name, email || null, avatar_url || null, updated_at, id);
    } finally {
      statement.finalizeSync();
    }
  },

  delete(id: number): void {
    const db = getDatabase();
    const statement = db.prepareSync('DELETE FROM users WHERE id = ?');
    try {
      statement.executeSync(id);
    } finally {
      statement.finalizeSync();
    }
  }
};
