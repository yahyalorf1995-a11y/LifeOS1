import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { DashboardScreen } from '../screens/DashboardScreen';
import { TodayPlanScreen } from '../screens/TodayPlanScreen';
import { GoalsScreen } from '../screens/GoalsScreen';
import { HabitsScreen } from '../screens/HabitsScreen';
import { LibraryScreen } from '../screens/LibraryScreen';
import { CoachScreen } from '../screens/CoachScreen';
import { ReviewScreen } from '../screens/ReviewScreen';
import { StatisticsScreen } from '../screens/StatisticsScreen';
import { SettingsScreen } from '../screens/SettingsScreen';

export type RootStackParamList = {
  Dashboard: undefined;
  TodayPlan: undefined;
  Goals: undefined;
  Habits: undefined;
  Library: undefined;
  Coach: undefined;
  Review: undefined;
  Statistics: undefined;
  Settings: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Dashboard"
        screenOptions={{
          headerStyle: { backgroundColor: '#1e293b' },
          headerTintColor: '#ffffff',
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      >
        <Stack.Screen name="Dashboard" component={DashboardScreen} options={{ title: 'لوحة التحكم - LifeOS' }} />
        <Stack.Screen name="TodayPlan" component={TodayPlanScreen} options={{ title: 'خطة اليوم' }} />
        <Stack.Screen name="Goals" component={GoalsScreen} options={{ title: 'الأهداف النشطة' }} />
        <Stack.Screen name="Habits" component={HabitsScreen} options={{ title: 'العادات' }} />
        <Stack.Screen name="Library" component={LibraryScreen} options={{ title: 'مكتبة المحتوى' }} />
        <Stack.Screen name="Coach" component={CoachScreen} options={{ title: 'المدرب الشخصي' }} />
        <Stack.Screen name="Review" component={ReviewScreen} options={{ title: 'المراجعات اليومية' }} />
        <Stack.Screen name="Statistics" component={StatisticsScreen} options={{ title: 'الإحصاءات والتقارير' }} />
        <Stack.Screen name="Settings" component={SettingsScreen} options={{ title: 'الإعدادات' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
