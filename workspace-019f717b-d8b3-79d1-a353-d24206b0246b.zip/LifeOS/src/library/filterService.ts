import { LibraryItem, LibraryFilterCriteria } from './types';
import { LibraryRepo } from './libraryRepo';

export const FilterService = {
  filter(criteria: LibraryFilterCriteria): LibraryItem[] {
    const allItems = LibraryRepo.findAll();

    return allItems.filter(item => {
      if (criteria.type && item.type !== criteria.type) return false;
      if (criteria.life_area && item.life_area !== criteria.life_area) return false;
      if (criteria.category && item.category !== criteria.category) return false;
      if (criteria.difficulty && item.difficulty !== criteria.difficulty) return false;
      if (criteria.max_estimated_time !== undefined && item.estimated_time > criteria.max_estimated_time) return false;
      if (criteria.energy_level && item.energy_level !== criteria.energy_level) return false;
      if (criteria.priority && item.priority !== criteria.priority) return false;
      if (criteria.location && item.location !== criteria.location) return false;
      
      if (criteria.tags && criteria.tags.length > 0) {
        const hasAllTags = criteria.tags.every(reqTag => 
          item.tags.some(itemTag => itemTag.toLowerCase() === reqTag.toLowerCase())
        );
        if (!hasAllTags) return false;
      }

      return true;
    });
  }
};
