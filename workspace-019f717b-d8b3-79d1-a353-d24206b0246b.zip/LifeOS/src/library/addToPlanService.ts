import { LibraryItem } from './types';
import { GoalRepo } from '../database/repositories/goalRepo';
import { HabitRepo } from '../database/repositories/habitRepo';
import { TaskRepo } from '../database/repositories/taskRepo';
import { RoutineRepo } from '../database/repositories/routineRepo';

export const AddToPlanService = {
  addToPlan(item: LibraryItem): number {
    const now = new Date().toISOString();

    switch (item.type) {
      case 'goal': {
        return GoalRepo.create({
          title: item.name,
          description: item.description,
          status: 'active',
          progress: 0.0,
          created_at: now
        });
      }
      case 'habit': {
        return HabitRepo.create({
          title: item.name,
          description: item.description,
          frequency: 'daily',
          target_value: 1,
          created_at: now
        });
      }
      case 'task':
      case 'activity':
      case 'solution': {
        return TaskRepo.create({
          title: item.name,
          description: item.description,
          status: 'pending',
          priority: item.priority,
          created_at: now
        });
      }
      case 'routine':
      case 'protocol': {
        return RoutineRepo.create({
          title: item.name,
          description: item.description,
          time_of_day: 'anytime',
          is_active: 1,
          created_at: now
        });
      }
      case 'review': {
        // Reviews can be added as tasks or templates; default to task
        return TaskRepo.create({
          title: item.name,
          description: item.description,
          status: 'pending',
          priority: item.priority,
          created_at: now
        });
      }
      default:
        throw new Error(`Unsupported library item type for planning: ${item.type}`);
    }
  }
};
