import { LibraryItem, LibraryFilterCriteria, LibrarySearchQuery } from './types';
import { LibraryRepo } from './libraryRepo';
import { SearchService } from './searchService';
import { FilterService } from './filterService';
import { AddToPlanService } from './addToPlanService';

export const LibraryService = {
  createItem(item: Omit<LibraryItem, 'id'>): number {
    return LibraryRepo.create(item);
  },

  getItem(id: number): LibraryItem | null {
    return LibraryRepo.findById(id);
  },

  getAllItems(): LibraryItem[] {
    return LibraryRepo.findAll();
  },

  deleteItem(id: number): void {
    LibraryRepo.delete(id);
  },

  search(query: LibrarySearchQuery): LibraryItem[] {
    return SearchService.search(query);
  },

  filter(criteria: LibraryFilterCriteria): LibraryItem[] {
    return FilterService.filter(criteria);
  },

  addToPlan(itemId: number): number {
    const item = LibraryRepo.findById(itemId);
    if (!item) {
      throw new Error(`Library item with id ${itemId} not found.`);
    }
    return AddToPlanService.addToPlan(item);
  }
};
