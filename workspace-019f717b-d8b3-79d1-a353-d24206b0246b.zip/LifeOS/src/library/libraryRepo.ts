import { getDatabase } from '../database/db';
import { LibraryItem, LibraryItemType, DifficultyLevel, EnergyLevel, PriorityLevel, LocationType } from './types';

interface DBRow {
  id: number;
  type: string;
  name: string;
  description: string | null;
  category: string;
  life_area: string;
  difficulty: string;
  estimated_time: number;
  energy_level: string;
  priority: string;
  location: string;
  tags: string;
  related_goals: string | null;
  related_habits: string | null;
  related_protocols: string | null;
  created_at: string;
}

export const LibraryRepo = {
  create(item: Omit<LibraryItem, 'id'>): number {
    const db = getDatabase();
    const stmt = db.prepareSync(
      `INSERT INTO library_items 
      (type, name, description, category, life_area, difficulty, estimated_time, energy_level, priority, location, tags, related_goals, related_habits, related_protocols, created_at) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    try {
      const res = stmt.executeSync(
        item.type,
        item.name,
        item.description || null,
        item.category,
        item.life_area,
        item.difficulty,
        item.estimated_time,
        item.energy_level,
        item.priority,
        item.location,
        JSON.stringify(item.tags || []),
        item.related_goals ? JSON.stringify(item.related_goals) : null,
        item.related_habits ? JSON.stringify(item.related_habits) : null,
        item.related_protocols ? JSON.stringify(item.related_protocols) : null,
        item.created_at
      );
      return res.lastInsertRowId;
    } finally {
      stmt.finalizeSync();
    }
  },

  findById(id: number): LibraryItem | null {
    const db = getDatabase();
    const stmt = db.prepareSync('SELECT * FROM library_items WHERE id = ?');
    try {
      const rows = stmt.executeSync(id).getAllSync() as DBRow[];
      if (rows.length === 0) return null;
      return mapRowToLibraryItem(rows[0]);
    } finally {
      stmt.finalizeSync();
    }
  },

  findAll(): LibraryItem[] {
    const db = getDatabase();
    const rows = db.getAllSync('SELECT * FROM library_items') as DBRow[];
    return rows.map(mapRowToLibraryItem);
  },

  delete(id: number): void {
    const db = getDatabase();
    const stmt = db.prepareSync('DELETE FROM library_items WHERE id = ?');
    try {
      stmt.executeSync(id);
    } finally {
      stmt.finalizeSync();
    }
  }
};

function mapRowToLibraryItem(row: DBRow): LibraryItem {
  return {
    id: row.id,
    type: row.type as LibraryItemType,
    name: row.name,
    description: row.description || undefined,
    category: row.category,
    life_area: row.life_area,
    difficulty: row.difficulty as DifficultyLevel,
    estimated_time: row.estimated_time,
    energy_level: row.energy_level as EnergyLevel,
    priority: row.priority as PriorityLevel,
    location: row.location as LocationType,
    tags: JSON.parse(row.tags || '[]'),
    related_goals: row.related_goals ? JSON.parse(row.related_goals) : undefined,
    related_habits: row.related_habits ? JSON.parse(row.related_habits) : undefined,
    related_protocols: row.related_protocols ? JSON.parse(row.related_protocols) : undefined,
    created_at: row.created_at,
  };
}
