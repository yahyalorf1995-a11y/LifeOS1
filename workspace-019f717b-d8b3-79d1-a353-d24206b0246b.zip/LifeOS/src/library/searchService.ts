import { LibraryItem, LibrarySearchQuery } from './types';
import { LibraryRepo } from './libraryRepo';

export const SearchService = {
  search(query: LibrarySearchQuery): LibraryItem[] {
    const allItems = LibraryRepo.findAll();

    return allItems.filter(item => {
      // Keyword match (Name or Description)
      if (query.keyword) {
        const kw = query.keyword.toLowerCase();
        const nameMatch = item.name.toLowerCase().includes(kw);
        const descMatch = item.description ? item.description.toLowerCase().includes(kw) : false;
        if (!nameMatch && !descMatch) return false;
      }

      // Type match
      if (query.type && item.type !== query.type) {
        return false;
      }

      // Life Area match
      if (query.life_area && item.life_area.toLowerCase() !== query.life_area.toLowerCase()) {
        return false;
      }

      // Category match
      if (query.category && item.category.toLowerCase() !== query.category.toLowerCase()) {
        return false;
      }

      // Tag match
      if (query.tag) {
        const hasTag = item.tags.some(t => t.toLowerCase() === query.tag?.toLowerCase());
        if (!hasTag) return false;
      }

      return true;
    });
  }
};
