import { LibraryRepo } from './libraryRepo';

export function seedLibraryContent(): void {
  const existing = LibraryRepo.findAll();
  if (existing.length > 0) {
    return; // Already seeded
  }

  const now = new Date().toISOString();

  const seedItems = [
    // --- GOALS LIBRARY ---
    {
      type: 'goal' as const,
      name: 'ختم القرآن الكريم بتدبر',
      description: 'قراءة جزء يومياً مع التدبر والتفسير الميسر.',
      category: 'الإيمان',
      life_area: 'الإيمان',
      difficulty: 'medium' as const,
      estimated_time: 20,
      energy_level: 'medium' as const,
      priority: 'high' as const,
      location: 'home' as const,
      tags: ['قرآن', 'إيمان', 'عِبَادة', 'يومي'],
      created_at: now
    },
    {
      type: 'goal' as const,
      name: 'بناء لياقة بدنية عالية وقوة عضلية',
      description: 'الالتزام بتمارين المقاومة والكارديو 4 أيام أسبوعياً.',
      category: 'اللياقة',
      life_area: 'الصحة',
      difficulty: 'hard' as const,
      estimated_time: 45,
      energy_level: 'high' as const,
      priority: 'high' as const,
      location: 'outdoor' as const,
      tags: ['رياضة', 'صحة', 'لياقة', 'جسم'],
      created_at: now
    },
    {
      type: 'goal' as const,
      name: 'قراءة 24 كتاباً في السنة',
      description: 'قراءة كتابين كل شهر في مجالات تطوير الذات والمال والتاريخ.',
      category: 'القراءة',
      life_area: 'تطوير الذات',
      difficulty: 'medium' as const,
      estimated_time: 30,
      energy_level: 'medium' as const,
      priority: 'medium' as const,
      location: 'home' as const,
      tags: ['قراءة', 'كتب', 'معرفة', 'تطوير'],
      created_at: now
    },
    {
      type: 'goal' as const,
      name: 'الوصول للحرية المالية والادخار الذكي',
      description: 'ادخار 20% من الدخل الشهري واستثمارها بحكمة.',
      category: 'إدارة المال',
      life_area: 'العمل',
      difficulty: 'hard' as const,
      estimated_time: 15,
      energy_level: 'low' as const,
      priority: 'high' as const,
      location: 'work' as const,
      tags: ['مال', 'ادخار', 'استثمار', 'ميزانية'],
      created_at: now
    },
    {
      type: 'goal' as const,
      name: 'تحسين العلاقة الزوجية وبناء ود مستدام',
      description: 'تخصيص وقت أسبوعي خاص ونقاشات عميقة وتقدير مستمر.',
      category: 'الزواج',
      life_area: 'العلاقات',
      difficulty: 'medium' as const,
      estimated_time: 60,
      energy_level: 'medium' as const,
      priority: 'high' as const,
      location: 'home' as const,
      tags: ['زواج', 'عائلة', 'حب', 'استقرار'],
      created_at: now
    },
    {
      type: 'goal' as const,
      name: 'التربية الإيجابية وبناء ذكريات للأطفال',
      description: 'الجلوس مع الأبناء يومياً، الاستماع لهم، وتعليمهم القيم.',
      category: 'الأبوة',
      life_area: 'العلاقات',
      difficulty: 'medium' as const,
      estimated_time: 30,
      energy_level: 'medium' as const,
      priority: 'high' as const,
      location: 'home' as const,
      tags: ['أبوة', 'أطفال', 'تربية', 'أسرة'],
      created_at: now
    },

    // --- HABITS LIBRARY ---
    {
      type: 'habit' as const,
      name: 'الاستيقاظ المبكر قبل الفجر',
      description: 'الاستيقاظ بتركيز وهدوء لبدء اليوم بنشاط.',
      category: 'تنظيم الروتين',
      life_area: 'الإنتاجية',
      difficulty: 'hard' as const,
      estimated_time: 10,
      energy_level: 'high' as const,
      priority: 'high' as const,
      location: 'home' as const,
      tags: ['استيقاظ', 'صباح', 'روتين', 'انضباط'],
      created_at: now
    },
    {
      type: 'habit' as const,
      name: 'شرب 2.5 لتر ماء يومياً',
      description: 'الحفاظ على ترطيب الجسم والنشاط الذهني.',
      category: 'الصحة',
      life_area: 'الصحة',
      difficulty: 'easy' as const,
      estimated_time: 2,
      energy_level: 'low' as const,
      priority: 'medium' as const,
      location: 'anywhere' as const,
      tags: ['ماء', 'صحة', 'حيوية'],
      created_at: now
    },
    {
      type: 'habit' as const,
      name: 'جلسة عمل عميق بدون مشتتات (90 دقيقة)',
      description: 'التركيز على أهم مهمة استراتيجية في اليوم.',
      category: 'الإنتاجية',
      life_area: 'العمل',
      difficulty: 'hard' as const,
      estimated_time: 90,
      energy_level: 'high' as const,
      priority: 'urgent' as const,
      location: 'work' as const,
      tags: ['تركيز', 'عمل', 'إنتاجية', 'عميق'],
      created_at: now
    },
    {
      type: 'habit' as const,
      name: 'المشي الرياضي اليومي (30 دقيقة)',
      description: 'تنشيط الدورة الدموية وصفاء الذهب.',
      category: 'اللياقة',
      life_area: 'الصحة',
      difficulty: 'medium' as const,
      estimated_time: 30,
      energy_level: 'medium' as const,
      priority: 'high' as const,
      location: 'outdoor' as const,
      tags: ['مشي', 'رياضة', 'صحة'],
      created_at: now
    },

    // --- ACTIVITIES LIBRARY ---
    {
      type: 'activity' as const,
      name: 'جلسة استرخاء وتأمل تنفسي',
      description: 'تنفس عميق 4-7-8 لخفض التوتر وإعادة ضبط الجهاز العصبي.',
      category: 'انخفاض الطاقة',
      life_area: 'الصحة',
      difficulty: 'easy' as const,
      estimated_time: 10,
      energy_level: 'low' as const,
      priority: 'medium' as const,
      location: 'home' as const,
      tags: ['استرخاء', 'تنفس', 'هدوء', 'طاقة'],
      created_at: now
    },
    {
      type: 'activity' as const,
      name: 'نزهة عائلية في الطبيعة',
      description: 'الخروج إلى حديقة أو مساحة خضراء مع الأسرة.',
      category: 'أنشطة أسرية',
      life_area: 'العلاقات',
      difficulty: 'easy' as const,
      estimated_time: 120,
      energy_level: 'medium' as const,
      priority: 'medium' as const,
      location: 'outdoor' as const,
      tags: ['عائلة', 'طبيعة', 'نزهة', 'أطفال'],
      created_at: now
    },
    {
      type: 'activity' as const,
      name: 'ترتيب وتنظيم مكتب العمل أو الغرفة',
      description: 'التخلص من الفوضى وتنظيم المكان لزيادة التركيز.',
      category: 'تنظيم المنزل',
      life_area: 'الإنتاجية',
      difficulty: 'easy' as const,
      estimated_time: 20,
      energy_level: 'medium' as const,
      priority: 'low' as const,
      location: 'home' as const,
      tags: ['ترتيب', 'منزل', 'مكتب', 'تنظيم'],
      created_at: now
    },

    // --- RECOVERY LIBRARY ---
    {
      type: 'recovery' as const,
      name: 'خطة التعافي السريع بعد الانقطاع',
      description: 'العودة التدريجية دون جلد ذات، التركيز على مهمة واحدة فقط في اليوم الأول.',
      category: 'التعافي بعد الانقطاع',
      life_area: 'تطوير الذات',
      difficulty: 'easy' as const,
      estimated_time: 15,
      energy_level: 'low' as const,
      priority: 'urgent' as const,
      location: 'home' as const,
      tags: ['تعافي', 'عودة', 'انقطاع', 'تحفيز'],
      created_at: now
    },
    {
      type: 'recovery' as const,
      name: 'إعادة ضبط الطاقة بعد يوم سيء',
      description: 'أخذ حمام دافئ، إغلاق الشاشات، النوم مبكراً، واعتبار اليوم صفحة جديدة.',
      category: 'التعافي بعد يوم سيء',
      life_area: 'الصحة',
      difficulty: 'easy' as const,
      estimated_time: 30,
      energy_level: 'low' as const,
      priority: 'high' as const,
      location: 'home' as const,
      tags: ['يوم_سيء', 'راحة', 'استشفاء', 'نوم'],
      created_at: now
    },

    // --- SOLUTIONS LIBRARY ---
    {
      type: 'solution' as const,
      name: 'قاعدة الـ 5 دقائق للتغلب على التسويف',
      description: 'ابدأ في المهمة لمدة 5 دقائق فقط؛ غالباً ستستمر بعدها.',
      category: 'التسويف',
      life_area: 'الإنتاجية',
      difficulty: 'easy' as const,
      estimated_time: 5,
      energy_level: 'low' as const,
      priority: 'urgent' as const,
      location: 'anywhere' as const,
      tags: ['تسويف', 'حفظ', 'تركيز', 'بدء'],
      created_at: now
    },
    {
      type: 'solution' as const,
      name: 'الديجيتال ديتوكس وحظر الهاتف المؤقت',
      description: 'وضع الهاتف في غرفة أخرى وتفعيل وضع عدم الإزعاج أثناء العمل.',
      category: 'كثرة استخدام الهاتف',
      life_area: 'الإنتاجية',
      difficulty: 'medium' as const,
      estimated_time: 60,
      energy_level: 'medium' as const,
      priority: 'high' as const,
      location: 'work' as const,
      tags: ['هاتف', 'تشتت', 'تركيز', 'ديجيتال'],
      created_at: now
    },

    // --- PROTOCOL LIBRARY ---
    {
      type: 'protocol' as const,
      name: 'بروتوكول تحسين النوم العميق (7 أيام)',
      description: 'مراحل متدرجة لإيقاف الشاشات قبل النوم، تعديل إضاءة الغرفة، وتثبيت موعد الاستيقاظ.',
      category: 'تحسين النوم',
      life_area: 'الصحة',
      difficulty: 'medium' as const,
      estimated_time: 20,
      energy_level: 'low' as const,
      priority: 'high' as const,
      location: 'home' as const,
      tags: ['نوم', 'صحة', 'بروتوكول', 'استرخاء'],
      created_at: now
    },
    {
      type: 'protocol' as const,
      name: 'بروتوكول التخلص من الإباحية وبناء الطهارة',
      description: 'منهجية متكاملة تشمل إغلاق الثغرات الرقمية، الدعم النفسي، وعلاج المثيرات.',
      category: 'التخلص من الإباحية',
      life_area: 'الإيمان',
      difficulty: 'hard' as const,
      estimated_time: 30,
      energy_level: 'high' as const,
      priority: 'urgent' as const,
      location: 'anywhere' as const,
      tags: ['تعافي', 'إيمان', 'بروتوكول', 'طهارة'],
      created_at: now
    }
  ];

  seedItems.forEach(item => {
    LibraryRepo.create(item);
  });
}
