export type LibraryItemType = 
  | 'goal' 
  | 'habit' 
  | 'protocol' 
  | 'routine' 
  | 'task' 
  | 'activity' 
  | 'solution' 
  | 'review'
  | 'recovery';

export type DifficultyLevel = 'easy' | 'medium' | 'hard';
export type EnergyLevel = 'low' | 'medium' | 'high';
export type PriorityLevel = 'low' | 'medium' | 'high' | 'urgent';
export type LocationType = 'home' | 'work' | 'outdoor' | 'anywhere';

export interface LibraryItem {
  id?: number;
  type: LibraryItemType;
  name: string;
  description?: string;
  category: string;
  life_area: string;
  difficulty: DifficultyLevel;
  estimated_time: number; // in minutes
  energy_level: EnergyLevel;
  priority: PriorityLevel;
  location: LocationType;
  tags: string[]; // parsed from or stored as JSON
  related_goals?: number[];
  related_habits?: number[];
  related_protocols?: number[];
  created_at: string;
}

export interface LibraryFilterCriteria {
  type?: LibraryItemType;
  life_area?: string;
  category?: string;
  difficulty?: DifficultyLevel;
  max_estimated_time?: number;
  energy_level?: EnergyLevel;
  priority?: PriorityLevel;
  location?: LocationType;
  tags?: string[];
}

export interface LibrarySearchQuery {
  keyword?: string;
  type?: LibraryItemType;
  life_area?: string;
  category?: string;
  tag?: string;
}
