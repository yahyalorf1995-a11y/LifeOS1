import { initDatabase, getDatabase } from '../database/db';
import { LibraryService } from './libraryService';
import { IntelligenceService } from '../engines/intelligenceService';

describe('Smart Content Library & Seeding Test', () => {
  beforeEach(() => {
    initDatabase();
  });

  it('should have seeded professional items across libraries', () => {
    const items = LibraryService.getAllItems();
    expect(items.length).toBeGreaterThan(10);

    const goals = items.filter(i => i.type === 'goal');
    const habits = items.filter(i => i.type === 'habit');
    const activities = items.filter(i => i.type === 'activity');
    const recovery = items.filter(i => i.type === 'recovery');
    const solutions = items.filter(i => i.type === 'solution');
    const protocols = items.filter(i => i.type === 'protocol');

    expect(goals.length).toBeGreaterThan(0);
    expect(habits.length).toBeGreaterThan(0);
    expect(activities.length).toBeGreaterThan(0);
    expect(recovery.length).toBeGreaterThan(0);
    expect(solutions.length).toBeGreaterThan(0);
    expect(protocols.length).toBeGreaterThan(0);
  });

  it('should support search engine across libraries', () => {
    const results = LibraryService.search({ keyword: 'نوم' });
    expect(results.length).toBeGreaterThan(0);
  });

  it('should integrate with Intelligence / Recommendation engines', () => {
    const recs = IntelligenceService.getRecommendations();
    expect(recs.length).toBeGreaterThan(0);
  });

  it('should allow adding library items to user plan', () => {
    const items = LibraryService.getAllItems();
    const habitItem = items.find(i => i.type === 'habit');
    if (habitItem && habitItem.id) {
      const planId = LibraryService.addToPlan(habitItem.id);
      expect(planId).toBeGreaterThan(0);
    }
  });
});
