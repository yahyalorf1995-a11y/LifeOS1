import { initDatabase, getDatabase } from '../database/db';
import { UserRepo } from '../database/repositories/userRepo';
import { SettingRepo } from '../database/repositories/settingRepo';

describe('Database and Repositories Test', () => {
  it('should initialize database without errors', () => {
    expect(() => initDatabase()).not.toThrow();
  });

  it('should perform CRUD operations on UserRepo', () => {
    initDatabase();
    const now = new Date().toISOString();
    const userId = UserRepo.create({
      name: 'Test User',
      email: 'test@lifeos.local',
      created_at: now,
      updated_at: now
    });
    expect(userId).toBeGreaterThan(0);

    const user = UserRepo.findById(userId);
    expect(user).not.toBeNull();
    expect(user?.name).toBe('Test User');

    UserRepo.update(userId, { name: 'Updated User' });
    const updated = UserRepo.findById(userId);
    expect(updated?.name).toBe('Updated User');

    UserRepo.delete(userId);
    const deleted = UserRepo.findById(userId);
    expect(deleted).toBeNull();
  });

  it('should perform set and get on SettingRepo', () => {
    initDatabase();
    SettingRepo.set('theme', 'dark');
    const val = SettingRepo.get('theme');
    expect(val).toBe('dark');
  });
});
