import { DailySessionRepo } from '../database/repositories/dailySessionRepo';

export const GuidanceEngine = {
  isUserStruggling(): boolean {
    const sessions = DailySessionRepo.findAll();
    if (sessions.length < 3) return false;

    // Check last 3 sessions completion rate
    const recent = sessions.slice(-3);
    const completedCount = recent.filter(s => s.completed === 1).length;

    // If 0 or 1 out of last 3 completed, user is struggling
    return completedCount <= 1;
  },

  getGuidanceAdvice(): string {
    if (this.isUserStruggling()) {
      return 'يبدو أنك تواجه صعوبة في الفترة الأخيرة. تم تبسيط خطتك اليومية لتشمل أقل عدد من المهام للتركيز على الاستمرارية وليس الكثرة.';
    }
    return 'أنت تسير بخطى ثابتة نحو أهدافك. حافظ على استمرارك اليومي!';
  },

  simplifyDailyLimit(defaultLimit: number): number {
    if (this.isUserStruggling()) {
      // Simplify plan by reducing daily item limit by half
      return Math.max(2, Math.floor(defaultLimit / 2));
    }
    return defaultLimit;
  }
};
