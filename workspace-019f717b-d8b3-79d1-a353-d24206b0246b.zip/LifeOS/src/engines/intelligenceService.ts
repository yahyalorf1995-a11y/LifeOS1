import { AnalysisEngine, UserBehaviorData } from './analysisEngine';
import { InsightEngine, Insight } from './insightEngine';
import { RecommendationEngine, ExplainableRecommendation } from './recommendationEngine';
import { RecoveryEngine, RecoveryPlan } from './recoveryEngine';
import { AdaptationEngine, UserAdaptationProfile } from './adaptationEngine';

export const IntelligenceService = {
  analyze(): UserBehaviorData {
    return AnalysisEngine.analyzeUserBehavior();
  },

  getInsights(): Insight[] {
    return InsightEngine.detectPatterns();
  },

  getRecommendations(): ExplainableRecommendation[] {
    return RecommendationEngine.generateRecommendations();
  },

  checkRecoveryStatus(): RecoveryPlan {
    return RecoveryEngine.evaluateRecoveryNeed();
  },

  getAdaptationProfile(): UserAdaptationProfile {
    return AdaptationEngine.learnUserPatterns();
  }
};
