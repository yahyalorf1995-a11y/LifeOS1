import { PlanningEngine } from './planningEngine';
import { GuidanceEngine } from './guidanceEngine';
import { ProgressEngine } from './progressEngine';
import { GoalRepo } from '../database/repositories/goalRepo';

export interface CoachResponse {
  greeting: string;
  topTask?: string;
  motivationAdvice: string;
  longTermGoalReminder: string;
  suggestedActivity?: string;
}

export const CoachEngine = {
  getDailyCoaching(): CoachResponse {
    const todayPlan = PlanningEngine.generateTodayPlan();
    const isStruggling = GuidanceEngine.isUserStruggling();
    const completionRate = ProgressEngine.calculateDailyCompletionRate();
    const activeGoals = GoalRepo.findAll().filter(g => g.status === 'active');

    let greeting = 'صباح الخير! يوم رائع ينتظرك.';
    if (isStruggling) {
      greeting = 'أهلاً بك يا بطل. نحن معك خطوة بخطوة للعودة بقوة.';
    } else if (completionRate === 100) {
      greeting = 'ألف مبروك إنجازك الكامل اليوم! أنت مبدع حقاً.';
    }

    const topTask = todayPlan.prioritizedTasks.length > 0 ? todayPlan.prioritizedTasks[0].title : undefined;

    let motivationAdvice = GuidanceEngine.getGuidanceAdvice();
    if (completionRate < 50 && !isStruggling) {
      motivationAdvice = 'لبداية سهلة، اختر مهمة واحدة صغيرة وأنجزها الآن لتستعيد الزخم.';
    }

    const longTermGoalReminder = activeGoals.length > 0
      ? `تذكر هدفك الأساسي: "${activeGoals[0].title}". كل يوم تقترب منه خطوة.`
      : 'أضف هدفاً طويل المدى لتوجيه بوصلتك الشخصية.';

    let suggestedActivity: string | undefined = undefined;
    if (completionRate >= 80) {
      suggestedActivity = 'لديك وقت فراغ ممتاز اليوم! ما رأيك في قراءة فصل من كتاب أو أخذ نزهة قصيرة؟';
    } else {
      suggestedActivity = 'خذ استراحة قصيرة لمدة 10 دقائق ثم عد لإكمال خطتك بهدوء.';
    }

    return {
      greeting,
      topTask,
      motivationAdvice,
      longTermGoalReminder,
      suggestedActivity
    };
  }
};
