import { DailySessionRepo } from '../database/repositories/dailySessionRepo';

export interface UserAdaptationProfile {
  mostProductiveTimeOfDay: string;
  mostSuccessfulHabitType: string;
  recommendedTaskLoad: number;
}

export const AdaptationEngine = {
  learnUserPatterns(): UserAdaptationProfile {
    const sessions = DailySessionRepo.findAll();
    
    // Heuristic learning from session timestamps
    let morningCount = 0;
    let eveningCount = 0;

    sessions.forEach(s => {
      const hour = new Date(s.timestamp).getHours();
      if (hour < 12) morningCount++;
      else eveningCount++;
    });

    const mostProductiveTimeOfDay = morningCount >= eveningCount ? 'الصباح (Morning Peak)' : 'المساء (Evening Peak)';

    return {
      mostProductiveTimeOfDay,
      mostSuccessfulHabitType: 'العادات اليومية القصيرة (Daily Micro-habits)',
      recommendedTaskLoad: 5
    };
  }
};
