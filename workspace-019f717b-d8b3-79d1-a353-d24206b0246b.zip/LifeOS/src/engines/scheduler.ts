import { Task, TaskRepo } from '../database/repositories/taskRepo';
import { Habit } from '../database/repositories/habitRepo';

export interface ScheduledSchedule {
  morning: (Task | Habit)[];
  afternoon: (Task | Habit)[];
  evening: (Task | Habit)[];
  rescheduledCount: number;
}

export const Scheduler = {
  MAX_DAILY_ITEMS: 6, // Prevents daily overload

  distributeSchedule(tasks: Task[], habits: Habit[]): ScheduledSchedule {
    const combined: (Task | Habit)[] = [...habits, ...tasks];
    
    // Limit total items to prevent overload
    const limitedItems = combined.slice(0, this.MAX_DAILY_ITEMS);

    const morning: (Task | Habit)[] = [];
    const afternoon: (Task | Habit)[] = [];
    const evening: (Task | Habit)[] = [];

    limitedItems.forEach((item, index) => {
      if (index % 3 === 0) morning.push(item);
      else if (index % 3 === 1) afternoon.push(item);
      else evening.push(item);
    });

    return {
      morning,
      afternoon,
      evening,
      rescheduledCount: Math.max(0, combined.length - this.MAX_DAILY_ITEMS)
    };
  },

  rescheduleIncompleteTasks(): number {
    const allTasks = TaskRepo.findAll();
    const today = new Date().toISOString().split('T')[0];
    let rescheduledCount = 0;

    allTasks.forEach(task => {
      if (task.status === 'pending' && task.due_date && task.due_date < today) {
        // Reschedule to today without infinite repetition
        TaskRepo.update(task.id!, { due_date: today });
        rescheduledCount++;
      }
    });

    return rescheduledCount;
  }
};
