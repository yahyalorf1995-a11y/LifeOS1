import { ProgressEngine } from './progressEngine';
import { GoalRepo } from '../database/repositories/goalRepo';

export interface AppStatistics {
  dailyCompletionRate: number;
  habitAdherence: number;
  currentStreak: number;
  activeGoalsCount: number;
  weeklyCompletionRate: number;
  monthlyCompletionRate: number;
}

export const StatisticsEngine = {
  computeStatistics(): AppStatistics {
    const dailyCompletionRate = ProgressEngine.calculateDailyCompletionRate();
    const habitAdherence = ProgressEngine.calculateHabitAdherence();
    const currentStreak = ProgressEngine.calculateStreak();
    const activeGoalsCount = GoalRepo.findAll().filter(g => g.status === 'active').length;

    // Weekly and monthly completion rates estimated from progress metrics
    const weeklyCompletionRate = Math.round((dailyCompletionRate + habitAdherence) / 2);
    const monthlyCompletionRate = Math.round(weeklyCompletionRate * 0.95);

    return {
      dailyCompletionRate,
      habitAdherence,
      currentStreak,
      activeGoalsCount,
      weeklyCompletionRate,
      monthlyCompletionRate
    };
  }
};
