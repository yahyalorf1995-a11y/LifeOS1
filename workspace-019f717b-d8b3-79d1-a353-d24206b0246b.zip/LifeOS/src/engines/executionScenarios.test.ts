import { initDatabase, getDatabase } from '../database/db';
import { ExecutionEngine } from './executionEngine';
import { ProgressEngine } from './progressEngine';
import { StatisticsEngine } from './statisticsEngine';
import { ReviewEngine } from './reviewEngine';
import { TaskRepo } from '../database/repositories/taskRepo';
import { GoalRepo } from '../database/repositories/goalRepo';
import { DailyPlanRepo } from '../database/repositories/dailyPlanRepo';

describe('Execution & Tracking Engine Scenarios', () => {
  beforeEach(() => {
    initDatabase();
    const db = getDatabase();
    db.execSync('DELETE FROM tasks;');
    db.execSync('DELETE FROM goals;');
    db.execSync('DELETE FROM daily_sessions;');
    db.execSync('DELETE FROM daily_plans;');
    db.execSync('DELETE FROM metrics;');
    db.execSync('DELETE FROM history;');
    db.execSync('DELETE FROM reviews;');
  });

  it('Scenario 1: Finish all tasks of the day', () => {
    const now = new Date().toISOString();
    const t1 = TaskRepo.create({ title: 'Task 1', status: 'pending', priority: 'high', created_at: now });
    const t2 = TaskRepo.create({ title: 'Task 2', status: 'pending', priority: 'medium', created_at: now });
    const planId = DailyPlanRepo.create({ date: '2026-07-17', created_at: now });

    ExecutionEngine.completeTask(t1, planId);
    ExecutionEngine.completeTask(t2, planId);

    const rate = ProgressEngine.calculateDailyCompletionRate();
    expect(rate).toBe(100);

    const stats = StatisticsEngine.computeStatistics();
    expect(stats.dailyCompletionRate).toBe(100);

    const reviewId = ReviewEngine.generateReview('daily', '2026-07-17', 'Great day!');
    expect(reviewId).toBeGreaterThan(0);
  });

  it('Scenario 2: Complete 0 tasks', () => {
    const now = new Date().toISOString();
    TaskRepo.create({ title: 'Task 1', status: 'pending', priority: 'high', created_at: now });

    const rate = ProgressEngine.calculateDailyCompletionRate();
    expect(rate).toBe(0);
  });

  it('Scenario 3: Complete half the plan', () => {
    const now = new Date().toISOString();
    const t1 = TaskRepo.create({ title: 'Task 1', status: 'pending', priority: 'high', created_at: now });
    TaskRepo.create({ title: 'Task 2', status: 'pending', priority: 'medium', created_at: now });
    const planId = DailyPlanRepo.create({ date: '2026-07-17', created_at: now });

    ExecutionEngine.completeTask(t1, planId);

    const rate = ProgressEngine.calculateDailyCompletionRate();
    expect(rate).toBe(50);
  });

  it('Scenario 4 & 5: Gap of several days and return after gap', () => {
    const now = new Date().toISOString();
    ExecutionEngine.recordDailyMetric('sleep', 6, 'hours', '2026-07-10');
    // Gap until 2026-07-17
    ExecutionEngine.recordDailyMetric('sleep', 8, 'hours', '2026-07-17');

    const metrics = TrackingEngineMockHelper(); // verify metrics recorded successfully
    expect(metrics.length).toBe(2);
  });

  it('Scenario 6: Delete a goal during execution', () => {
    const now = new Date().toISOString();
    const goalId = GoalRepo.create({ title: 'Temporary Goal', status: 'active', created_at: now });
    expect(GoalRepo.findById(goalId)).not.toBeNull();

    GoalRepo.delete(goalId);
    expect(GoalRepo.findById(goalId)).toBeNull();
  });

  it('Scenario 7: Modify plan during the day (Reschedule task)', () => {
    const now = new Date().toISOString();
    const taskId = TaskRepo.create({ title: 'Flexible Task', status: 'pending', priority: 'low', created_at: now });

    ExecutionEngine.rescheduleTask(taskId, '2026-07-18');
    const updated = TaskRepo.findById(taskId);
    expect(updated?.due_date).toBe('2026-07-18');
  });
});

function TrackingEngineMockHelper() {
  return MetricRepo.findAll();
}
