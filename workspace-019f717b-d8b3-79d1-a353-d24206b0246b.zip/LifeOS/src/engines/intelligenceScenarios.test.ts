import { initDatabase, getDatabase } from '../database/db';
import { IntelligenceService } from './intelligenceService';
import { TaskRepo } from '../database/repositories/taskRepo';
import { MetricRepo } from '../database/repositories/metricRepo';
import { DailySessionRepo } from '../database/repositories/dailySessionRepo';
import { DailyPlanRepo } from '../database/repositories/dailyPlanRepo';
import { GoalRepo } from '../database/repositories/goalRepo';
import { HabitRepo } from '../database/repositories/habitRepo';

describe('Analysis & Intelligence Engine Scenarios', () => {
  beforeEach(() => {
    initDatabase();
    const db = getDatabase();
    db.execSync('DELETE FROM tasks;');
    db.execSync('DELETE FROM metrics;');
    db.execSync('DELETE FROM daily_sessions;');
    db.execSync('DELETE FROM daily_plans;');
    db.execSync('DELETE FROM goals;');
    db.execSync('DELETE FROM habits;');
  });

  it('Scenario 1: Committed user', () => {
    const now = new Date().toISOString();
    MetricRepo.create({ metric_name: 'sleep', metric_value: 8, unit: 'hours', recorded_date: '2026-07-17' });
    TaskRepo.create({ title: 'T1', status: 'completed', priority: 'high', created_at: now });

    const insights = IntelligenceService.getInsights();
    expect(insights.length).toBeGreaterThan(0);
    const recs = IntelligenceService.getRecommendations();
    expect(recs[0].reason).toBeDefined();
    expect(recs[0].basedOnData).toBeDefined();
    expect(recs[0].expectedBenefit).toBeDefined();
  });

  it('Scenario 2: Struggling user', () => {
    const now = new Date().toISOString();
    const planId = DailyPlanRepo.create({ date: '2026-07-16', created_at: now });
    DailySessionRepo.create({ daily_plan_id: planId, session_type: 'task', completed: 0, timestamp: now });
    DailySessionRepo.create({ daily_plan_id: planId, session_type: 'task', completed: 0, timestamp: now });

    const recovery = IntelligenceService.checkRecoveryStatus();
    expect(recovery.isRecoveryNeeded).toBe(true);
    expect(recovery.suggestedAction).toBeDefined();
  });

  it('Scenario 3: User returned after a gap', () => {
    const now = new Date().toISOString();
    MetricRepo.create({ metric_name: 'sleep', metric_value: 7, unit: 'hours', recorded_date: '2026-07-10' });
    // Gap recorded
    MetricRepo.create({ metric_name: 'sleep', metric_value: 7, unit: 'hours', recorded_date: '2026-07-17' });

    const profile = IntelligenceService.getAdaptationProfile();
    expect(profile.mostProductiveTimeOfDay).toBeDefined();
  });

  it('Scenario 4: User achieving goals rapidly', () => {
    const now = new Date().toISOString();
    GoalRepo.create({ title: 'Fast Goal', status: 'completed', created_at: now });

    const analysis = IntelligenceService.analyze();
    expect(analysis).toBeDefined();
  });

  it('Scenario 5: User with too many goals / tasks', () => {
    const now = new Date().toISOString();
    for (let i = 0; i < 10; i++) {
      TaskRepo.create({ title: `Task ${i}`, status: 'pending', priority: 'medium', created_at: now });
    }

    const insights = IntelligenceService.getInsights();
    const overload = insights.some(i => i.pattern.includes('كثرة المهام'));
    expect(overload).toBe(true);

    const recs = IntelligenceService.getRecommendations();
    expect(recs.some(r => r.actionType === 'reduce_tasks')).toBe(true);
  });

  it('Scenario 6: User constantly changing habits', () => {
    const now = new Date().toISOString();
    HabitRepo.create({ title: 'H1', frequency: 'daily', target_value: 1, created_at: now });
    HabitRepo.create({ title: 'H2', frequency: 'weekly', target_value: 1, created_at: now });

    const profile = IntelligenceService.getAdaptationProfile();
    expect(profile.mostSuccessfulHabitType).toBeDefined();
  });
});
