import { ReviewRepo, Review } from '../database/repositories/reviewRepo';
import { StatisticsEngine } from './statisticsEngine';

export const ReviewEngine = {
  generateReview(reviewType: 'daily' | 'weekly' | 'monthly' | 'yearly', periodKey: string, userNotes?: string): number {
    const stats = StatisticsEngine.computeStatistics();

    let wins = `إنجاز بنسبة ${stats.dailyCompletionRate}% في المهام، والتزام بالعادات بنسبة ${stats.habitAdherence}%.`;
    let challenges = stats.currentStreak === 0 ? 'التحدي الأكبر كان الحفاظ على الاستمرارية اليومية.' : 'لا توجد تحديات كبرى، الأداء مستقر.';
    let lessons = 'الاستمرارية فوق الكثرة هي مفتاح النجاح طويل الأمد.';
    let rating = Math.min(5, Math.max(1, Math.round(stats.dailyCompletionRate / 20)));

    if (userNotes) {
      wins += ` | ملاحظات المستخدم: ${userNotes}`;
    }

    const now = new Date().toISOString();
    return ReviewRepo.create({
      review_type: reviewType,
      period_key: periodKey,
      wins,
      challenges,
      lessons,
      rating,
      created_at: now
    });
  }
};
