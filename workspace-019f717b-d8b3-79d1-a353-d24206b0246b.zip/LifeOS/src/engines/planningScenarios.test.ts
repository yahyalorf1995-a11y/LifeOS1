import { initDatabase, getDatabase } from '../database/db';
import { PlannerService } from './plannerService';
import { GoalRepo } from '../database/repositories/goalRepo';
import { HabitRepo } from '../database/repositories/habitRepo';
import { TaskRepo } from '../database/repositories/taskRepo';
import { DailySessionRepo } from '../database/repositories/dailySessionRepo';
import { DailyPlanRepo } from '../database/repositories/dailyPlanRepo';

describe('Planning & Guidance Engine Scenarios', () => {
  beforeEach(() => {
    initDatabase();
    // Clear tables for clean test state
    const db = getDatabase();
    db.execSync('DELETE FROM goals;');
    db.execSync('DELETE FROM habits;');
    db.execSync('DELETE FROM tasks;');
    db.execSync('DELETE FROM daily_sessions;');
    db.execSync('DELETE FROM daily_plans;');
  });

  it('Scenario 1: New user (empty active items)', () => {
    const plan = PlannerService.createTodayPlan('2026-07-17');
    expect(plan).toBeDefined();
    expect(plan.schedule.morning.length).toBe(0);
    expect(plan.isStruggling).toBe(false);
  });

  it('Scenario 2: User with 1 goal', () => {
    const now = new Date().toISOString();
    GoalRepo.create({
      title: 'Goal 1',
      status: 'active',
      created_at: now
    });

    const plan = PlannerService.createTodayPlan('2026-07-17');
    expect(plan.recommendations.suggestedTasks.length).toBeGreaterThan(0);
  });

  it('Scenario 3: User with multiple goals', () => {
    const now = new Date().toISOString();
    GoalRepo.create({ title: 'Goal 1', status: 'active', created_at: now });
    GoalRepo.create({ title: 'Goal 2', status: 'active', created_at: now });

    const plan = PlannerService.createTodayPlan('2026-07-17');
    expect(plan.recommendations.suggestedTasks.length).toBeGreaterThanOrEqual(2);
  });

  it('Scenario 4: Struggling user (missed tasks over recent sessions)', () => {
    const now = new Date().toISOString();
    const planId = DailyPlanRepo.create({ date: '2026-07-16', created_at: now });
    
    // Add 3 recent sessions with 0 completed (struggling)
    DailySessionRepo.create({ daily_plan_id: planId, session_type: 'task', completed: 0, timestamp: now });
    DailySessionRepo.create({ daily_plan_id: planId, session_type: 'task', completed: 0, timestamp: now });
    DailySessionRepo.create({ daily_plan_id: planId, session_type: 'task', completed: 0, timestamp: now });

    const plan = PlannerService.createTodayPlan('2026-07-17');
    expect(plan.isStruggling).toBe(true);
    expect(plan.guidanceMessage).toContain('تبسيط');
  });

  it('Scenario 5: User who completed 0 tasks', () => {
    const now = new Date().toISOString();
    TaskRepo.create({ title: 'Task 1', status: 'pending', priority: 'high', created_at: now });

    const plan = PlannerService.createTodayPlan('2026-07-17');
    expect(plan.prioritizedTasks.length).toBe(1);
    expect(plan.schedule.morning.length + plan.schedule.afternoon.length + plan.schedule.evening.length).toBe(1);
  });

  it('Scenario 6: User who finished all tasks', () => {
    const now = new Date().toISOString();
    TaskRepo.create({ title: 'Task Done', status: 'completed', priority: 'high', created_at: now });

    const plan = PlannerService.createTodayPlan('2026-07-17');
    expect(plan.prioritizedTasks.length).toBe(0);
  });
});
