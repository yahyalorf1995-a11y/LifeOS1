import { Task } from '../database/repositories/taskRepo';
import { Habit } from '../database/repositories/habitRepo';
import { Goal } from '../database/repositories/goalRepo';

export interface PrioritizedItem {
  id: number;
  type: 'task' | 'habit' | 'goal' | string;
  title: string;
  priorityScore: number;
  urgency: string;
  dueDate?: string;
}

export const PriorityManager = {
  calculatePriorityScore(priority: string, dueDate?: string): number {
    let baseScore = 10;
    switch (priority) {
      case 'urgent': baseScore = 40; break;
      case 'high': baseScore = 30; break;
      case 'medium': baseScore = 20; break;
      case 'low': baseScore = 10; break;
      default: baseScore = 15;
    }

    if (dueDate) {
      const today = new Date().toISOString().split('T')[0];
      if (dueDate < today) {
        baseScore += 25; // Overdue bonus
      } else if (dueDate === today) {
        baseScore += 15; // Due today bonus
      }
    }

    return baseScore;
  },

  rankTasks(tasks: Task[]): PrioritizedItem[] {
    const items: PrioritizedItem[] = tasks.map(task => ({
      id: task.id!,
      type: 'task',
      title: task.title,
      priorityScore: this.calculatePriorityScore(task.priority, task.due_date),
      urgency: task.priority,
      dueDate: task.due_date
    }));

    return items.sort((a, b) => b.priorityScore - a.priorityScore);
  },

  rankHabits(habits: Habit[]): PrioritizedItem[] {
    // Habits prioritize continuity (daily frequency gets higher base)
    return habits.map(habit => ({
      id: habit.id!,
      type: 'habit',
      title: habit.title,
      priorityScore: habit.frequency === 'daily' ? 35 : 25,
      urgency: 'medium'
    })).sort((a, b) => b.priorityScore - a.priorityScore);
  }
};
