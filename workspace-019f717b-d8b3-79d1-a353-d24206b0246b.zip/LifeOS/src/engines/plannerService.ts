import { PlanningEngine, TodayPlanResult, WeeklyPlanResult } from './planningEngine';
import { RecommendationService, Recommendations } from './recommendationService';
import { GuidanceEngine } from './guidanceEngine';

export const PlannerService = {
  createTodayPlan(date?: string): TodayPlanResult {
    return PlanningEngine.generateTodayPlan(date);
  },

  createWeeklyPlan(weekKey: string): WeeklyPlanResult {
    return PlanningEngine.generateWeeklyPlan(weekKey);
  },

  getRecommendations(): Recommendations {
    return RecommendationService.generateRecommendations();
  },

  checkGuidanceStatus(): { isStruggling: boolean; advice: string } {
    return {
      isStruggling: GuidanceEngine.isUserStruggling(),
      advice: GuidanceEngine.getGuidanceAdvice()
    };
  }
};
