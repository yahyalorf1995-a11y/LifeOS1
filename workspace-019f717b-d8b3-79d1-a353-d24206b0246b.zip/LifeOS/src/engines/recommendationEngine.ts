import { AnalysisEngine } from './analysisEngine';
import { InsightEngine } from './insightEngine';

export interface ExplainableRecommendation {
  id: string;
  title: string;
  reason: string;
  basedOnData: string;
  expectedBenefit: string;
  actionType: 'reduce_tasks' | 'increase_tasks' | 'add_habit' | 'remove_habit' | 'rest_day' | 'simplify_plan';
}

export const RecommendationEngine = {
  generateRecommendations(): ExplainableRecommendation[] {
    const data = AnalysisEngine.analyzeUserBehavior();
    const insights = InsightEngine.detectPatterns();
    const recs: ExplainableRecommendation[] = [];

    const overloadInsight = insights.find(i => i.pattern.includes('كثرة المهام'));
    if (overloadInsight || data.tasks.length > 7) {
      recs.push({
        id: 'rec_reduce_tasks',
        title: 'تقليل عدد المهام اليومية',
        reason: 'الضغط الزائد وعدد المهام المرتفع يؤديان إلى الإرهاق وتأجيل المهام.',
        basedOnData: `عدد المهام الحالية (${data.tasks.length} مهمة) يتجاوز الحد الموصى به للاستمرارية الفعالة.`,
        expectedBenefit: 'رفع نسبة إنجاز المهام اليومية وتقليل التوتر وتحسين التركيز.',
        actionType: 'reduce_tasks'
      });
    }

    const sleepInsight = insights.find(i => i.pattern.includes('انخفاض النوم'));
    if (sleepInsight || data.averageSleep < 6.5) {
      recs.push({
        id: 'rec_rest_day',
        title: 'أخذ يوم راحة أو تعديل جدول النوم',
        reason: 'نقص النوم المتكرر يضعف الطاقة ويقلل من كفاءة اتخاذ القرار.',
        basedOnData: `متوسط النوم المسجل هو ${data.averageSleep.toFixed(1)} ساعة فقط في الأيام الأخيرة.`,
        expectedBenefit: 'استعادة الطاقة العقلية والجسدية ورفع الإنتاجية في الأيام اللاحقة.',
        actionType: 'rest_day'
      });
    }

    // Default proactive recommendation if user is stable
    if (recs.length === 0) {
      recs.push({
        id: 'rec_add_habit',
        title: 'إضافة عادة صغيرة جديدة',
        reason: 'مستوى استقرارك الحالي ممتاز، وهو الوقت الأنسب لبناء عادة جديدة تدريجيًا.',
        basedOnData: `معدل إنجازك مستقر عند ${data.averageCompletionRate.toFixed(0)}%.`,
        expectedBenefit: 'توسيع نطاق تطويرك الشخصي دون إحداث ضغط إضافي.',
        actionType: 'add_habit'
      });
    }

    return recs;
  }
};
