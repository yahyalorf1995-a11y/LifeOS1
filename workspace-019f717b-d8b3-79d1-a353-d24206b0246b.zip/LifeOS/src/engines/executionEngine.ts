import { TaskRepo, Task } from '../database/repositories/taskRepo';
import { DailySessionRepo } from '../database/repositories/dailySessionRepo';
import { MetricRepo } from '../database/repositories/metricRepo';
import { HistoryRepo } from '../database/repositories/historyRepo';

export const ExecutionEngine = {
  startTask(taskId: number): void {
    TaskRepo.update(taskId, { status: 'in_progress' });
    const now = new Date().toISOString();
    HistoryRepo.create({
      entity_type: 'task',
      entity_id: taskId,
      action: 'start',
      details: 'Task started',
      timestamp: now
    });
  },

  pauseTask(taskId: number): void {
    TaskRepo.update(taskId, { status: 'pending' });
    const now = new Date().toISOString();
    HistoryRepo.create({
      entity_type: 'task',
      entity_id: taskId,
      action: 'pause',
      details: 'Task paused',
      timestamp: now
    });
  },

  completeTask(taskId: number, dailyPlanId?: number): void {
    TaskRepo.update(taskId, { status: 'completed' });
    const now = new Date().toISOString();
    
    if (dailyPlanId) {
      DailySessionRepo.create({
        daily_plan_id: dailyPlanId,
        task_id: taskId,
        session_type: 'task',
        duration_minutes: 15,
        completed: 1,
        notes: 'Task completed',
        timestamp: now
      });
    }

    HistoryRepo.create({
      entity_type: 'task',
      entity_id: taskId,
      action: 'complete',
      details: 'Task completed successfully',
      timestamp: now
    });
  },

  skipTask(taskId: number): void {
    TaskRepo.update(taskId, { status: 'cancelled' });
    const now = new Date().toISOString();
    HistoryRepo.create({
      entity_type: 'task',
      entity_id: taskId,
      action: 'skip',
      details: 'Task skipped',
      timestamp: now
    });
  },

  rescheduleTask(taskId: number, newDueDate: string): void {
    TaskRepo.update(taskId, { due_date: newDueDate });
    const now = new Date().toISOString();
    HistoryRepo.create({
      entity_type: 'task',
      entity_id: taskId,
      action: 'reschedule',
      details: `Rescheduled to ${newDueDate}`,
      timestamp: now
    });
  },

  logHabitExecution(habitId: number, dailyPlanId: number, completed: boolean, notes?: string): void {
    const now = new Date().toISOString();
    DailySessionRepo.create({
      daily_plan_id: dailyPlanId,
      habit_id: habitId,
      session_type: 'habit',
      duration_minutes: 10,
      completed: completed ? 1 : 0,
      notes: notes || (completed ? 'Habit completed' : 'Habit missed'),
      timestamp: now
    });

    HistoryRepo.create({
      entity_type: 'habit',
      entity_id: habitId,
      action: completed ? 'complete' : 'miss',
      details: notes || 'Habit log recorded',
      timestamp: now
    });
  },

  recordDailyMetric(metricName: string, value: number, unit?: string, dateStr?: string, notes?: string): void {
    const date = dateStr || new Date().toISOString().split('T')[0];
    MetricRepo.create({
      metric_name: metricName,
      metric_value: value,
      unit: unit || '',
      recorded_date: date,
      notes: notes || null
    });
  }
};
