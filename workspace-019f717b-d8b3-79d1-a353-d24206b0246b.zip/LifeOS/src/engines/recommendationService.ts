import { Goal, GoalRepo } from '../database/repositories/goalRepo';
import { Habit, HabitRepo } from '../database/repositories/habitRepo';
import { Routine, RoutineRepo } from '../database/repositories/routineRepo';

export interface Recommendations {
  suggestedTasks: string[];
  suggestedHabits: string[];
}

export const RecommendationService = {
  generateRecommendations(): Recommendations {
    const activeGoals = GoalRepo.findAll().filter(g => g.status === 'active');
    const allHabits = HabitRepo.findAll();
    const activeRoutines = RoutineRepo.findAll().filter(r => r.is_active === 1);

    const suggestedTasks: string[] = [];
    const suggestedHabits: string[] = [];

    activeGoals.forEach(goal => {
      suggestedTasks.push(`تطوير خطوة عملية نحو الهدف: ${goal.title}`);
    });

    allHabits.forEach(habit => {
      suggestedHabits.push(habit.title);
    });

    activeRoutines.forEach(routine => {
      suggestedTasks.push(`تطبيق روتين: ${routine.title}`);
    });

    return {
      suggestedTasks: suggestedTasks.slice(0, 3), // Limit suggestions
      suggestedHabits: suggestedHabits.slice(0, 3)
    };
  }
};
