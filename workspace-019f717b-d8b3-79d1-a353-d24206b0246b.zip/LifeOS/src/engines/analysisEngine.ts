import { MetricRepo, Metric } from '../database/repositories/metricRepo';
import { TaskRepo, Task } from '../database/repositories/taskRepo';
import { DailySessionRepo, DailySession } from '../database/repositories/dailySessionRepo';

export interface UserBehaviorData {
  metrics: Metric[];
  tasks: Task[];
  sessions: DailySession[];
  averageSleep: number;
  averageCompletionRate: number;
}

export const AnalysisEngine = {
  analyzeUserBehavior(): UserBehaviorData {
    const metrics = MetricRepo.findAll();
    const tasks = TaskRepo.findAll();
    const sessions = DailySessionRepo.findAll();

    const sleepMetrics = metrics.filter(m => m.metric_name.toLowerCase().includes('sleep') || m.metric_name.includes('نوم'));
    const totalSleep = sleepMetrics.reduce((acc, curr) => acc + curr.metric_value, 0);
    const averageSleep = sleepMetrics.length > 0 ? totalSleep / sleepMetrics.length : 7.5;

    const completedTasks = tasks.filter(t => t.status === 'completed').length;
    const averageCompletionRate = tasks.length > 0 ? (completedTasks / tasks.length) * 100 : 80;

    return {
      metrics,
      tasks,
      sessions,
      averageSleep,
      averageCompletionRate
    };
  }
};
