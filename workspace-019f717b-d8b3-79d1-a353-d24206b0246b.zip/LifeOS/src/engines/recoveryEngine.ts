import { TaskRepo } from '../database/repositories/taskRepo';
import { DailySessionRepo } from '../database/repositories/dailySessionRepo';

export interface RecoveryPlan {
  isRecoveryNeeded: boolean;
  message: string;
  suggestedAction: string;
}

export const RecoveryEngine = {
  evaluateRecoveryNeed(): RecoveryPlan {
    const sessions = DailySessionRepo.findAll();
    const tasks = TaskRepo.findAll();

    // Check if user has missed multiple recent sessions or has many overdue tasks
    const recentSessions = sessions.slice(-3);
    const missedCount = recentSessions.filter(s => s.completed === 0).length;
    const pendingTasksCount = tasks.filter(t => t.status === 'pending').length;

    if (missedCount >= 2 || pendingTasksCount > 10) {
      return {
        isRecoveryNeeded: true,
        message: 'تم رصد انخفاض في وتيرة الإنجاز أو تراكم مهام.',
        suggestedAction: 'تم تبسيط الخطة تلقائيًا لتركز على خطوة واحدة صغيرة اليوم (Micro-step) للعودة تدريجيًا دون إعادة تعبيرك لنقطة الصفر.'
      };
    }

    return {
      isRecoveryNeeded: false,
      message: 'الأداء مستقر ولا حاجة لبرنامج تعافي حالياً.',
      suggestedAction: 'استمر على خطتك الحالية.'
    };
  }
};
