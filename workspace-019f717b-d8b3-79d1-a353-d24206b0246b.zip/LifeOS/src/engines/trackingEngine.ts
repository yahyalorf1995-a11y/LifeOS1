import { MetricRepo, Metric } from '../database/repositories/metricRepo';
import { DailySessionRepo, DailySession } from '../database/repositories/dailySessionRepo';
import { HistoryRepo, HistoryRecord } from '../database/repositories/historyRepo';

export const TrackingEngine = {
  getMetricsForDate(date: string): Metric[] {
    const all = MetricRepo.findAll();
    return all.filter(m => m.recorded_date === date);
  },

  getAllMetrics(): Metric[] {
    return MetricRepo.findAll();
  },

  getSessionHistory(): DailySession[] {
    return DailySessionRepo.findAll();
  },

  getActivityHistory(): HistoryRecord[] {
    return HistoryRepo.findAll();
  }
};
