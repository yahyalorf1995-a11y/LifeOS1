import { AnalysisEngine, UserBehaviorData } from './analysisEngine';

export interface Insight {
  pattern: string;
  description: string;
  severity: 'info' | 'warning' | 'success';
}

export const InsightEngine = {
  detectPatterns(): Insight[] {
    const data = AnalysisEngine.analyzeUserBehavior();
    const insights: Insight[] = [];

    // Pattern 1: Sleep vs Productivity
    if (data.averageSleep < 6.5) {
      insights.push({
        pattern: 'انخفاض النوم يؤدي إلى انخفاض الإنجاز',
        description: `متوسط ساعات النوم لديك (${data.averageSleep.toFixed(1)} ساعة) أقل من المعدل المثالي، مما يؤثر على تركيزك وإنتاجيتك.`,
        severity: 'warning'
      });
    } else {
      insights.push({
        pattern: 'جودة النوم جيدة',
        description: `متوسط ساعات النوم (${data.averageSleep.toFixed(1)} ساعة) يدعم إنتاجيتك واستقرارك.`,
        severity: 'success'
      });
    }

    // Pattern 2: Task Overload
    if (data.tasks.length > 8) {
      insights.push({
        pattern: 'كثرة المهام تقلل نسبة الإنجاز',
        description: `لديك ${data.tasks.length} مهمة مسجلة في نفس الوقت، مما قد يسبب تشتتًا وانخفاضًا في معدل الإنجاز.`,
        severity: 'warning'
      });
    }

    // Pattern 3: Habit Adherence
    const habitSessions = data.sessions.filter(s => s.session_type === 'habit');
    const completedHabits = habitSessions.filter(s => s.completed === 1).length;
    const habitAdherence = habitSessions.length > 0 ? (completedHabits / habitSessions.length) * 100 : 100;

    if (habitAdherence >= 80) {
      insights.push({
        pattern: 'التزام ممتاز بالعادات',
        description: `نسبة التزامك بالعادات بلغت ${habitAdherence.toFixed(0)}%، مما يعزز الاستمرارية.`,
        severity: 'success'
      });
    } else if (habitAdherence < 50 && habitSessions.length > 0) {
      insights.push({
        pattern: 'مؤشر انخفاض الالتزام بالعادات',
        description: `نسبة الالتزام بالعادات انخفضت إلى ${habitAdherence.toFixed(0)}%، ويُفضل تبسيط الخطة.`,
        severity: 'warning'
      });
    }

    return insights;
  }
};
