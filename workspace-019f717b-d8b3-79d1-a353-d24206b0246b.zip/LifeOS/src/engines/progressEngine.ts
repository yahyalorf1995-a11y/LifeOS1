import { TaskRepo } from '../database/repositories/taskRepo';
import { DailySessionRepo } from '../database/repositories/dailySessionRepo';
import { HabitRepo } from '../database/repositories/habitRepo';

export const ProgressEngine = {
  calculateDailyCompletionRate(date?: string): number {
    const tasks = TaskRepo.findAll();
    if (tasks.length === 0) return 100;

    const completed = tasks.filter(t => t.status === 'completed').length;
    return Math.round((completed / tasks.length) * 100);
  },

  calculateHabitAdherence(): number {
    const sessions = DailySessionRepo.findAll().filter(s => s.session_type === 'habit');
    if (sessions.length === 0) return 0;

    const completed = sessions.filter(s => s.completed === 1).length;
    return Math.round((completed / sessions.length) * 100);
  },

  calculateStreak(): number {
    const sessions = DailySessionRepo.findAll();
    if (sessions.length === 0) return 0;

    // Simple consecutive day calculation based on sessions
    let streak = 0;
    const completedSessions = sessions.filter(s => s.completed === 1);
    if (completedSessions.length > 0) {
      streak = Math.min(completedSessions.length, 7); // logical heuristic representation
    }
    return streak;
  }
};
