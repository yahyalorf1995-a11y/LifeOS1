import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, ScrollView, ActivityIndicator, TouchableOpacity } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import { ReviewEngine } from '../engines/reviewEngine';
import { ReviewRepo, Review } from '../database/repositories/reviewRepo';

type Props = NativeStackScreenProps<RootStackParamList, 'Review'>;

export function ReviewScreen({ navigation }: Props) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);

  const loadReviews = () => {
    try {
      setLoading(true);
      const all = ReviewRepo.findAll();
      setReviews(all);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'خطأ في تحميل المراجعات');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReviews();
  }, []);

  const handleGenerateReview = () => {
    const today = new Date().toISOString().split('T')[0];
    ReviewEngine.generateReview('daily', today, 'توليد تلقائي من التطبيق');
    loadReviews();
  };

  if (loading && reviews.length === 0) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={styles.loadingText}>جاري تحميل المراجعات...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>⚠️ {error}</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <TouchableOpacity style={styles.genBtn} onPress={handleGenerateReview}>
        <Text style={styles.genBtnText}>✨ توليد مراجعة اليوم تلقائياً</Text>
      </TouchableOpacity>

      <Text style={styles.headerTitle}>🌙 سجل المراجعات ({reviews.length})</Text>

      {reviews.length === 0 ? (
        <View style={styles.emptyCard}>
          <Text style={styles.emptyText}>لا توجد مراجعات مسجلة حتى الآن.</Text>
        </View>
      ) : (
        reviews.map(rev => (
          <View key={rev.id} style={styles.card}>
            <Text style={styles.revType}>[{rev.review_type.toUpperCase()}] - فترة: {rev.period_key}</Text>
            <Text style={styles.revWins}>🏆 الإنجازات: {rev.wins}</Text>
            {rev.challenges && <Text style={styles.revText}>⚠️ التحديات: {rev.challenges}</Text>}
            {rev.lessons && <Text style={styles.revText}>💡 الدروس: {rev.lessons}</Text>}
            <Text style={styles.revRating}>التقييم: {rev.rating} / 5 ⭐</Text>
          </View>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc', padding: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8fafc' },
  loadingText: { marginTop: 10, color: '#64748b' },
  errorText: { color: '#ef4444', fontSize: 16, textAlign: 'center', padding: 20 },
  genBtn: { backgroundColor: '#3b82f6', borderRadius: 12, padding: 16, alignItems: 'center', marginBottom: 16, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  genBtnText: { color: '#ffffff', fontWeight: 'bold', fontSize: 16 },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1e293b', marginBottom: 12 },
  emptyCard: { backgroundColor: '#ffffff', borderRadius: 12, padding: 20, alignItems: 'center' },
  emptyText: { color: '#64748b', fontSize: 14, textAlign: 'center' },
  card: { backgroundColor: '#ffffff', borderRadius: 12, padding: 16, marginBottom: 12, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  revType: { fontSize: 12, fontWeight: 'bold', color: '#3b82f6', marginBottom: 6 },
  revWins: { fontSize: 14, fontWeight: '600', color: '#1e293b', marginBottom: 4 },
  revText: { fontSize: 13, color: '#475569', marginBottom: 4 },
  revRating: { fontSize: 12, color: '#eab308', fontWeight: 'bold', marginTop: 4 }
});
