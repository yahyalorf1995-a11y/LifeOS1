import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, ScrollView, ActivityIndicator, TouchableOpacity, TextInput } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import { LibraryService } from '../library/libraryService';
import { LibraryItem } from '../library/types';

type Props = NativeStackScreenProps<RootStackParamList, 'Library'>;

export function LibraryScreen({ navigation }: Props) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [items, setItems] = useState<LibraryItem[]>([]);
  const [searchKey, setSearchKey] = useState('');

  const loadLibrary = (keyword?: string) => {
    try {
      setLoading(true);
      const res = keyword ? LibraryService.search({ keyword }) : LibraryService.getAllItems();
      setItems(res);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'خطأ في تحميل مكتبة المحتوى');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLibrary();
  }, []);

  const handleSearch = (text: string) => {
    setSearchKey(text);
    loadLibrary(text);
  };

  const handleAddToPlan = (itemId: number) => {
    try {
      LibraryService.addToPlan(itemId);
      alert('تمت الإضافة إلى خطتك بنجاح! ✓');
    } catch (err: any) {
      alert('فشل الإضافة: ' + err.message);
    }
  };

  if (loading && items.length === 0) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={styles.loadingText}>جاري تحميل مكتبة المحتوى...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>⚠️ {error}</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.searchInput}
        placeholder="ابحث في الأهداف، العادات، البروتوكولات..."
        placeholderTextColor="#94a3b8"
        value={searchKey}
        onChangeText={handleSearch}
      />
      <ScrollView>
        <Text style={styles.headerTitle}>📚 عناصر المكتبة الذكية ({items.length})</Text>
        {items.length === 0 ? (
          <View style={styles.emptyCard}>
            <Text style={styles.emptyText}>لا توجد نتائج مطابقة للبحث.</Text>
          </View>
        ) : (
          items.map(item => (
            <View key={item.id} style={styles.card}>
              <View style={{ flex: 1 }}>
                <Text style={styles.itemType}>[{item.type.toUpperCase()}] - {item.category}</Text>
                <Text style={styles.itemName}>{item.name}</Text>
                {item.description && <Text style={styles.itemDesc}>{item.description}</Text>}
                <Text style={styles.itemMeta}>المجال: {item.life_area} | الوقت: {item.estimated_time}د</Text>
              </View>
              {item.id && (
                <TouchableOpacity style={styles.addBtn} onPress={() => handleAddToPlan(item.id!)}>
                  <Text style={styles.addBtnText}>أضف للخطة +</Text>
                </TouchableOpacity>
              )}
            </View>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc', padding: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8fafc' },
  loadingText: { marginTop: 10, color: '#64748b' },
  errorText: { color: '#ef4444', fontSize: 16, textAlign: 'center', padding: 20 },
  searchInput: { backgroundColor: '#ffffff', borderRadius: 10, paddingHorizontal: 16, paddingVertical: 12, marginBottom: 16, fontSize: 14, borderWidth: 1, borderColor: '#e2e8f0' },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1e293b', marginBottom: 12 },
  emptyCard: { backgroundColor: '#ffffff', borderRadius: 12, padding: 20, alignItems: 'center' },
  emptyText: { color: '#64748b', fontSize: 14, textAlign: 'center' },
  card: { backgroundColor: '#ffffff', borderRadius: 12, padding: 16, marginBottom: 12, flexDirection: 'row', alignItems: 'center', shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  itemType: { fontSize: 11, fontWeight: 'bold', color: '#3b82f6', marginBottom: 2 },
  itemName: { fontSize: 16, fontWeight: 'bold', color: '#1e293b', marginBottom: 4 },
  itemDesc: { fontSize: 13, color: '#475569', marginBottom: 6 },
  itemMeta: { fontSize: 11, color: '#64748b' },
  addBtn: { backgroundColor: '#3b82f6', paddingVertical: 8, paddingHorizontal: 12, borderRadius: 8, marginLeft: 8 },
  addBtnText: { color: '#ffffff', fontWeight: 'bold', fontSize: 12 }
});
