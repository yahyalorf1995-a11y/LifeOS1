import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import { PlanningEngine, TodayPlanResult } from '../engines/planningEngine';
import { CoachEngine, CoachResponse } from '../engines/coachEngine';
import { ProgressEngine } from '../engines/progressEngine';
import { ExecutionEngine } from '../engines/executionEngine';
import { GoalRepo, Goal } from '../database/repositories/goalRepo';

type Props = NativeStackScreenProps<RootStackParamList, 'Dashboard'>;

export function DashboardScreen({ navigation }: Props) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [plan, setPlan] = useState<TodayPlanResult | null>(null);
  const [coach, setCoach] = useState<CoachResponse | null>(null);
  const [completionRate, setCompletionRate] = useState(0);
  const [streak, setStreak] = useState(0);
  const [topGoal, setTopGoal] = useState<Goal | null>(null);

  const loadDashboardData = () => {
    try {
      setLoading(true);
      const todayPlan = PlanningEngine.generateTodayPlan();
      const coachData = CoachEngine.getDailyCoaching();
      const rate = ProgressEngine.calculateDailyCompletionRate();
      const currentStreak = ProgressEngine.calculateStreak();
      const goals = GoalRepo.findAll().filter(g => g.status === 'active');

      setPlan(todayPlan);
      setCoach(coachData);
      setCompletionRate(rate);
      setStreak(currentStreak);
      setTopGoal(goals.length > 0 ? goals[0] : null);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء تحميل لوحة القيادة');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, []);

  const handleCompleteTask = (taskId: number) => {
    ExecutionEngine.completeTask(taskId);
    loadDashboardData();
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={styles.loadingText}>جاري تجهيز مركز القيادة الشخصي...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>⚠️ {error}</Text>
      </View>
    );
  }

  const topTask = plan?.prioritizedTasks && plan.prioritizedTasks.length > 0 ? plan.prioritizedTasks[0] : null;

  return (
    <ScrollView style={styles.container}>
      {/* SECTION 1: Day Beginning */}
      <View style={styles.card}>
        <Text style={styles.dateLabel}>📅 {plan?.date}</Text>
        <Text style={styles.greeting}>{coach?.greeting}</Text>
        <Text style={styles.coachBody}>{coach?.motivationAdvice}</Text>
      </View>

      {/* SECTION 2: Today's Main Goal / Top Task */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>🎯 أهم هدف ومهمة اليوم</Text>
      </View>
      <View style={styles.primaryCard}>
        <Text style={styles.primaryGoalTitle}>
          {topGoal ? `الهدف: ${topGoal.title}` : (topTask ? topTask.title : 'لا توجد مهام رئيسية اليوم')}
        </Text>
        <Text style={styles.primaryGoalDesc}>
          {topTask ? `الأولوية القصوى: ${topTask.urgency}` : 'استمتع بيومك أو أضف هدفاً جديداً من المكتبة.'}
        </Text>
        {topTask && (
          <TouchableOpacity style={styles.actionBtn} onPress={() => handleCompleteTask(topTask.id)}>
            <Text style={styles.actionBtnText}>إنجاز المهمة الرئيسية ✓</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* SECTION 3: Today's Plan (Tasks & Habits) */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>📋 خطة اليوم المجدولة</Text>
      </View>
      {plan?.prioritizedTasks.length === 0 ? (
        <View style={styles.card}>
          <Text style={styles.emptyText}>أحسنت! لا توجد مهام معلقة الآن.</Text>
        </View>
      ) : (
        plan?.prioritizedTasks.map(task => (
          <View key={task.id} style={styles.taskCard}>
            <View style={{ flex: 1 }}>
              <Text style={styles.taskName}>{task.title}</Text>
              <Text style={styles.taskMeta}>الحالة: معلق | الأولوية: {task.urgency}</Text>
            </View>
            <TouchableOpacity style={styles.taskDoneBtn} onPress={() => handleCompleteTask(task.id)}>
              <Text style={styles.taskDoneText}>تم</Text>
            </TouchableOpacity>
          </View>
        ))
      )}

      {/* SECTION 4: Coach Card (Single Suggestion) */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>💡 مساعد اليوم الذكي</Text>
      </View>
      <View style={styles.coachCard}>
        <Text style={styles.coachCardText}>
          {coach?.suggestedActivity || 'ركز على إنجاز مهامك الأساسية مبكراً لتحظى بوقت راحة كافٍ مساءً.'}
        </Text>
      </View>

      {/* SECTION 5: Quick Progress */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>📊 التقدم السريع</Text>
      </View>
      <View style={styles.statsRow}>
        <View style={styles.statBox}>
          <Text style={styles.statVal}>{completionRate}%</Text>
          <Text style={styles.statLbl}>إنجاز اليوم</Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statVal}>{streak} أيام</Text>
          <Text style={styles.statLbl}>الاستمرارية</Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statVal}>3 / 5</Text>
          <Text style={styles.statLbl}>مستوى الطاقة</Text>
        </View>
      </View>

      {/* SECTION 6: Quick Action Buttons */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>⚡ إجراءات سريعة</Text>
      </View>
      <View style={styles.quickGrid}>
        <TouchableOpacity style={styles.quickBtn} onPress={() => navigation.navigate('TodayPlan')}>
          <Text style={styles.quickBtnText}>+ إنجاز مهمة</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.quickBtn} onPress={() => navigation.navigate('Habits')}>
          <Text style={styles.quickBtnText}>+ تسجيل عادة</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.quickBtn} onPress={() => navigation.navigate('Review')}>
          <Text style={styles.quickBtnText}>🌙 مراجعة اليوم</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.quickBtn} onPress={() => navigation.navigate('Library')}>
          <Text style={styles.quickBtnText}>📚 مكتبة المحتوى</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc', padding: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8fafc' },
  loadingText: { marginTop: 10, color: '#64748b' },
  errorText: { color: '#ef4444', fontSize: 16, textAlign: 'center', padding: 20 },
  card: { backgroundColor: '#ffffff', borderRadius: 12, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  dateLabel: { fontSize: 12, fontWeight: 'bold', color: '#3b82f6', marginBottom: 4 },
  greeting: { fontSize: 16, fontWeight: 'bold', color: '#1e293b', marginBottom: 6 },
  coachBody: { fontSize: 14, color: '#475569' },
  sectionHeader: { marginBottom: 8, marginTop: 12 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#1e293b' },
  primaryCard: { backgroundColor: '#1e293b', borderRadius: 12, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 6, elevation: 3 },
  primaryGoalTitle: { fontSize: 16, fontWeight: 'bold', color: '#ffffff', marginBottom: 6 },
  primaryGoalDesc: { fontSize: 13, color: '#94a3b8', marginBottom: 12 },
  actionBtn: { backgroundColor: '#3b82f6', paddingVertical: 10, paddingHorizontal: 16, borderRadius: 8, alignSelf: 'flex-start' },
  actionBtnText: { color: '#ffffff', fontWeight: 'bold', fontSize: 13 },
  emptyText: { color: '#64748b', fontSize: 14, textAlign: 'center' },
  taskCard: { backgroundColor: '#ffffff', borderRadius: 12, padding: 14, flexDirection: 'row', alignItems: 'center', marginBottom: 8, shadowColor: '#000', shadowOpacity: 0.03, shadowRadius: 3, elevation: 1 },
  taskName: { fontSize: 14, fontWeight: '600', color: '#1e293b', marginBottom: 2 },
  taskMeta: { fontSize: 11, color: '#64748b' },
  taskDoneBtn: { backgroundColor: '#22c55e', paddingVertical: 6, paddingHorizontal: 12, borderRadius: 6 },
  taskDoneText: { color: '#ffffff', fontWeight: 'bold', fontSize: 12 },
  coachCard: { backgroundColor: '#eff6ff', borderRadius: 12, padding: 14, borderWidth: 1, borderColor: '#bfdbfe', marginBottom: 16 },
  coachCardText: { fontSize: 14, color: '#1e40af', lineHeight: 20 },
  statsRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 16 },
  statBox: { flex: 1, backgroundColor: '#ffffff', borderRadius: 12, padding: 12, alignItems: 'center', marginHorizontal: 4, shadowColor: '#000', shadowOpacity: 0.03, shadowRadius: 3, elevation: 1 },
  statVal: { fontSize: 16, fontWeight: 'bold', color: '#3b82f6' },
  statLbl: { fontSize: 11, color: '#64748b', marginTop: 2 },
  quickGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginBottom: 30 },
  quickBtn: { width: '48%', backgroundColor: '#ffffff', borderRadius: 10, padding: 14, alignItems: 'center', marginBottom: 10, borderWidth: 1, borderColor: '#e2e8f0' },
  quickBtnText: { fontSize: 13, fontWeight: '600', color: '#334155' }
});
