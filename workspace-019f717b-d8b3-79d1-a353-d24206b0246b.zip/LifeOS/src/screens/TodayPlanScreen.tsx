import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, ScrollView, ActivityIndicator, TouchableOpacity } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import { PlanningEngine, TodayPlanResult } from '../engines/planningEngine';
import { ExecutionEngine } from '../engines/executionEngine';

type Props = NativeStackScreenProps<RootStackParamList, 'TodayPlan'>;

export function TodayPlanScreen({ navigation }: Props) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [plan, setPlan] = useState<TodayPlanResult | null>(null);

  const loadPlan = () => {
    try {
      setLoading(true);
      const todayPlan = PlanningEngine.generateTodayPlan();
      setPlan(todayPlan);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'خطأ في توليد خطة اليوم');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPlan();
  }, []);

  const handleCompleteTask = (taskId: number) => {
    ExecutionEngine.completeTask(taskId);
    loadPlan();
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={styles.loadingText}>جاري تجهيز خطة اليوم الذكية...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>⚠️ {error}</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      {/* Date & Guidance Banner */}
      <View style={styles.card}>
        <Text style={styles.dateTitle}>📅 تاريخ اليوم: {plan?.date}</Text>
        {plan?.isStruggling && (
          <View style={styles.warningBox}>
            <Text style={styles.warningText}>⚠️ وضع التعافي مفعل: {plan.guidanceMessage}</Text>
          </View>
        )}
        {!plan?.isStruggling && (
          <Text style={styles.guidanceText}>{plan?.guidanceMessage}</Text>
        )}
      </View>

      {/* Prioritized Tasks Section */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>🎯 المهام ذات الأولوية اليوم</Text>
      </View>

      {plan?.prioritizedTasks.length === 0 ? (
        <View style={styles.emptyCard}>
          <Text style={styles.emptyText}>لا توجد مهام معلقة اليوم. رائع!</Text>
        </View>
      ) : (
        plan?.prioritizedTasks.map(task => (
          <View key={task.id} style={styles.taskCard}>
            <View style={{ flex: 1 }}>
              <Text style={styles.taskTitle}>{task.title}</Text>
              <Text style={styles.taskMeta}>الأولوية: {task.urgency} | النقاط: {task.priorityScore}</Text>
            </View>
            <TouchableOpacity style={styles.completeBtn} onPress={() => handleCompleteTask(task.id)}>
              <Text style={styles.completeBtnText}>إنجاز ✓</Text>
            </TouchableOpacity>
          </View>
        ))
      )}

      {/* Schedule Distribution */}
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>⏰ توزيع الجدول اليومي</Text>
      </View>
      <View style={styles.card}>
        <Text style={styles.scheduleTitle}>الصباح ({plan?.schedule.morning.length || 0} عناصر)</Text>
        <Text style={styles.scheduleTitle}>الظهيرة ({plan?.schedule.afternoon.length || 0} عناصر)</Text>
        <Text style={styles.scheduleTitle}>المساء ({plan?.schedule.evening.length || 0} عناصر)</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc', padding: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8fafc' },
  loadingText: { marginTop: 10, color: '#64748b' },
  errorText: { color: '#ef4444', fontSize: 16, textAlign: 'center', padding: 20 },
  card: { backgroundColor: '#ffffff', borderRadius: 12, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  dateTitle: { fontSize: 16, fontWeight: 'bold', color: '#1e293b', marginBottom: 8 },
  guidanceText: { fontSize: 14, color: '#475569' },
  warningBox: { backgroundColor: '#fef2f2', padding: 10, borderRadius: 8, borderWidth: 1, borderColor: '#fca5a5' },
  warningText: { color: '#991b1b', fontSize: 14 },
  sectionHeader: { marginBottom: 12, marginTop: 8 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#1e293b' },
  emptyCard: { backgroundColor: '#ffffff', borderRadius: 12, padding: 20, alignItems: 'center', marginBottom: 16 },
  emptyText: { color: '#64748b', fontSize: 14 },
  taskCard: { backgroundColor: '#ffffff', borderRadius: 12, padding: 16, flexDirection: 'row', alignItems: 'center', marginBottom: 12, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  taskTitle: { fontSize: 15, fontWeight: '600', color: '#1e293b', marginBottom: 4 },
  taskMeta: { fontSize: 12, color: '#64748b' },
  completeBtn: { backgroundColor: '#22c55e', paddingVertical: 8, paddingHorizontal: 14, borderRadius: 8 },
  completeBtnText: { color: '#ffffff', fontWeight: 'bold', fontSize: 14 },
  scheduleTitle: { fontSize: 14, color: '#334155', paddingVertical: 4 }
});
