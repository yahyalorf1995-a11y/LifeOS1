import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, ScrollView, ActivityIndicator, Switch } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import { UserPreferenceManager } from '../notifications/userPreferenceManager';
import { NotificationPreferences } from '../notifications/types';

type Props = NativeStackScreenProps<RootStackParamList, 'Settings'>;

export function SettingsScreen({ navigation }: Props) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [prefs, setPrefs] = useState<NotificationPreferences | null>(null);

  useEffect(() => {
    try {
      setLoading(true);
      const p = UserPreferenceManager.getPreferences();
      setPrefs(p);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'خطأ في تحميل الإعدادات');
    } finally {
      setLoading(false);
    }
  }, []);

  const handleToggleNotifications = (value: boolean) => {
    if (prefs) {
      const updated = { ...prefs, enabled: value };
      setPrefs(updated);
      UserPreferenceManager.savePreferences(updated);
    }
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={styles.loadingText}>جاري تحميل الإعدادات...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>⚠️ {error}</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.headerTitle}>⚙️ إعدادات التطبيق والإشعارات</Text>

      <View style={styles.card}>
        <View style={{ flex: 1 }}>
          <Text style={styles.settingTitle}>تفعيل الإشعارات الذكية</Text>
          <Text style={styles.settingDesc}>استقبال تذكيرات المدرب الشخصي والإرشاد اليومي</Text>
        </View>
        <Switch
          value={prefs?.enabled ?? true}
          onValueChange={handleToggleNotifications}
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc', padding: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8fafc' },
  loadingText: { marginTop: 10, color: '#64748b' },
  errorText: { color: '#ef4444', fontSize: 16, textAlign: 'center', padding: 20 },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1e293b', marginBottom: 16 },
  card: { backgroundColor: '#ffffff', borderRadius: 12, padding: 16, marginBottom: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  settingTitle: { fontSize: 15, fontWeight: '600', color: '#1e293b', marginBottom: 2 },
  settingDesc: { fontSize: 12, color: '#64748b' }
});
