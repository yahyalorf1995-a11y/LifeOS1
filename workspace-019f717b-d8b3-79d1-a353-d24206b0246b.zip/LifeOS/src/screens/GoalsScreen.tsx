import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, ScrollView, ActivityIndicator } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import { GoalRepo, Goal } from '../database/repositories/goalRepo';

type Props = NativeStackScreenProps<RootStackParamList, 'Goals'>;

export function GoalsScreen({ navigation }: Props) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [goals, setGoals] = useState<Goal[]>([]);

  useEffect(() => {
    try {
      setLoading(true);
      const allGoals = GoalRepo.findAll();
      setGoals(allGoals);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'خطأ في تحميل الأهداف');
    } finally {
      setLoading(false);
    }
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={styles.loadingText}>جاري تحميل الأهداف...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>⚠️ {error}</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.headerTitle}>🎯 الأهداف النشطة ({goals.length})</Text>
      {goals.length === 0 ? (
        <View style={styles.emptyCard}>
          <Text style={styles.emptyText}>لا توجد أهداف مسجلة. يمكنك إضافتها من مكتبة المحتوى.</Text>
        </View>
      ) : (
        goals.map(goal => (
          <View key={goal.id} style={styles.card}>
            <Text style={styles.goalTitle}>{goal.title}</Text>
            {goal.description && <Text style={styles.goalDesc}>{goal.description}</Text>}
            <Text style={styles.goalMeta}>الحالة: {goal.status} | التقدم: {(goal.progress || 0) * 100}%</Text>
          </View>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc', padding: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8fafc' },
  loadingText: { marginTop: 10, color: '#64748b' },
  errorText: { color: '#ef4444', fontSize: 16, textAlign: 'center', padding: 20 },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1e293b', marginBottom: 16 },
  emptyCard: { backgroundColor: '#ffffff', borderRadius: 12, padding: 20, alignItems: 'center' },
  emptyText: { color: '#64748b', fontSize: 14, textAlign: 'center' },
  card: { backgroundColor: '#ffffff', borderRadius: 12, padding: 16, marginBottom: 12, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  goalTitle: { fontSize: 16, fontWeight: 'bold', color: '#1e293b', marginBottom: 6 },
  goalDesc: { fontSize: 14, color: '#475569', marginBottom: 8 },
  goalMeta: { fontSize: 12, color: '#64748b' }
});
