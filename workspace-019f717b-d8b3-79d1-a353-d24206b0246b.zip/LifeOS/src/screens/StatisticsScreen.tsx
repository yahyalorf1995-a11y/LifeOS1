import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, ScrollView, ActivityIndicator } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import { StatisticsEngine, AppStatistics } from '../engines/statisticsEngine';

type Props = NativeStackScreenProps<RootStackParamList, 'Statistics'>;

export function StatisticsScreen({ navigation }: Props) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<AppStatistics | null>(null);

  useEffect(() => {
    try {
      setLoading(true);
      const res = StatisticsEngine.computeStatistics();
      setStats(res);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'خطأ في حساب الإحصاءات');
    } finally {
      setLoading(false);
    }
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={styles.loadingText}>جاري حساب الإحصاءات والتقارير...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>⚠️ {error}</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.headerTitle}>📊 لوحة الإحصاءات الشاملة</Text>

      <View style={styles.card}>
        <Text style={styles.statLabel}>نسبة إنجاز اليوم</Text>
        <Text style={styles.statValue}>{stats?.dailyCompletionRate}%</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.statLabel}>نسبة الالتزام بالعادات</Text>
        <Text style={styles.statValue}>{stats?.habitAdherence}%</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.statLabel}>الأيام المتتالية (Streak)</Text>
        <Text style={styles.statValue}>{stats?.currentStreak} يوم</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.statLabel}>معدل الإنجاز الأسبوعي</Text>
        <Text style={styles.statValue}>{stats?.weeklyCompletionRate}%</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.statLabel}>معدل الإنجاز الشهري</Text>
        <Text style={styles.statValue}>{stats?.monthlyCompletionRate}%</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.statLabel}>الأهداف النشطة حالياً</Text>
        <Text style={styles.statValue}>{stats?.activeGoalsCount}</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc', padding: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8fafc' },
  loadingText: { marginTop: 10, color: '#64748b' },
  errorText: { color: '#ef4444', fontSize: 16, textAlign: 'center', padding: 20 },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1e293b', marginBottom: 16 },
  card: { backgroundColor: '#ffffff', borderRadius: 12, padding: 16, marginBottom: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  statLabel: { fontSize: 15, color: '#475569', fontWeight: '600' },
  statValue: { fontSize: 18, fontWeight: 'bold', color: '#3b82f6' }
});
