import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, ScrollView, ActivityIndicator } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import { HabitRepo, Habit } from '../database/repositories/habitRepo';

type Props = NativeStackScreenProps<RootStackParamList, 'Habits'>;

export function HabitsScreen({ navigation }: Props) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [habits, setHabits] = useState<Habit[]>([]);

  useEffect(() => {
    try {
      setLoading(true);
      const allHabits = HabitRepo.findAll();
      setHabits(allHabits);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'خطأ في تحميل العادات');
    } finally {
      setLoading(false);
    }
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={styles.loadingText}>جاري تحميل العادات...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>⚠️ {error}</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.headerTitle}>🔄 العادات اليومية ({habits.length})</Text>
      {habits.length === 0 ? (
        <View style={styles.emptyCard}>
          <Text style={styles.emptyText}>لا توجد عادات مسجلة حالياً.</Text>
        </View>
      ) : (
        habits.map(habit => (
          <View key={habit.id} style={styles.card}>
            <Text style={styles.habitTitle}>{habit.title}</Text>
            {habit.description && <Text style={styles.habitDesc}>{habit.description}</Text>}
            <Text style={styles.habitMeta}>التكرار: {habit.frequency} | القيمة المستهدفة: {habit.target_value}</Text>
          </View>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc', padding: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8fafc' },
  loadingText: { marginTop: 10, color: '#64748b' },
  errorText: { color: '#ef4444', fontSize: 16, textAlign: 'center', padding: 20 },
  headerTitle: { fontSize: 18, fontWeight: 'bold', color: '#1e293b', marginBottom: 16 },
  emptyCard: { backgroundColor: '#ffffff', borderRadius: 12, padding: 20, alignItems: 'center' },
  emptyText: { color: '#64748b', fontSize: 14, textAlign: 'center' },
  card: { backgroundColor: '#ffffff', borderRadius: 12, padding: 16, marginBottom: 12, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  habitTitle: { fontSize: 16, fontWeight: 'bold', color: '#1e293b', marginBottom: 6 },
  habitDesc: { fontSize: 14, color: '#475569', marginBottom: 8 },
  habitMeta: { fontSize: 12, color: '#64748b' }
});
