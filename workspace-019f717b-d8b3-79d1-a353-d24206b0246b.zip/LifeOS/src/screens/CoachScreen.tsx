import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, ScrollView, ActivityIndicator } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/AppNavigator';
import { CoachEngine, CoachResponse } from '../engines/coachEngine';

type Props = NativeStackScreenProps<RootStackParamList, 'Coach'>;

export function CoachScreen({ navigation }: Props) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [coach, setCoach] = useState<CoachResponse | null>(null);

  useEffect(() => {
    try {
      setLoading(true);
      const res = CoachEngine.getDailyCoaching();
      setCoach(res);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'خطأ في تحميل رسائل المدرب');
    } finally {
      setLoading(false);
    }
  }, []);

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={styles.loadingText}>جاري استشارة المدرب الشخصي...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>⚠️ {error}</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.cardTitle}>🌅 تحية اليوم</Text>
        <Text style={styles.cardBody}>{coach?.greeting}</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>🎯 أهم مهمة مقترحة</Text>
        <Text style={styles.cardBody}>{coach?.topTask || 'لا توجد مهام رئيسية اليوم، استمتع بوقتك أو أضف هدفاً.'}</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>💡 نصيحة التحفيز والإرشاد</Text>
        <Text style={styles.cardBody}>{coach?.motivationAdvice}</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>🏔️ تذكير الهدف طويل المدى</Text>
        <Text style={styles.cardBody}>{coach?.longTermGoalReminder}</Text>
      </View>

      {coach?.suggestedActivity && (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>⭐ نشاط مقترح لوقت الفراغ</Text>
          <Text style={styles.cardBody}>{coach.suggestedActivity}</Text>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc', padding: 16 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8fafc' },
  loadingText: { marginTop: 10, color: '#64748b' },
  errorText: { color: '#ef4444', fontSize: 16, textAlign: 'center', padding: 20 },
  card: { backgroundColor: '#ffffff', borderRadius: 12, padding: 16, marginBottom: 16, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  cardTitle: { fontSize: 16, fontWeight: 'bold', color: '#1e293b', marginBottom: 8 },
  cardBody: { fontSize: 14, color: '#334155', lineHeight: 20 }
});
