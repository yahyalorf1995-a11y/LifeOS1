# LifeOS - Personal Intelligent Coach

## Project Structure

```text
LifeOS/
├── assets/             # Static assets (fonts, images, icons, themes)
├── docs/               # Architecture documentation, design docs, specs
└── src/                # Source code root
    ├── ai/             # Local/offline AI model integration & coach prompt engines
    ├── analytics/      # Progress analytics, life metrics, and habit stats calculation
    ├── components/     # Reusable UI building blocks (atoms, molecules)
    ├── constants/      # App constants, configuration values, design tokens
    ├── database/       # Local database schema, migrations, and ORM configuration (offline-first)
    ├── engines/        # Core LifeOS business engines (Habit Engine, Routine Engine, Goal Engine)
    ├── hooks/          # Custom React/UI hooks
    ├── library/        # Third-party wrappers, utilities, and helper modules
    ├── notifications/  # Local notification scheduler and reminders engine
    ├── screens/        # Full application screens / views
    ├── services/       # External/internal device services (sensors, hardware, sync)
    ├── storage/        # Local secure key-value and state persistence layer
    ├── tests/          # Unit, integration, and end-to-end tests
    ├── types/          # TypeScript type definitions and interfaces
    └── utils/          # Pure helper functions, formatters, and date/time handlers
```

## Architecture Principles
- **Offline-First / Local-Only**: Designed entirely for a single user with local storage and database. No backend, cloud, login, or multi-user overhead.
- **Modularity & Separation of Concerns**: Clear boundaries between core intelligence (`engines/`, `ai/`), data management (`database/`, `storage/`), and presentation (`screens/`, `components/`).
- **Scalability**: Structured to support future growth in personal coaching algorithms without coupling UI to business logic.
