import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, ActivityIndicator } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { initDatabase } from './src/database/db';
import { AppNavigator } from './src/navigation/AppNavigator';

export default function App() {
  const [isInitialized, setIsInitialized] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      initDatabase();
      setIsInitialized(true);
    } catch (err: any) {
      setError(err.message || 'فشل تهيئة التطبيق وقاعدة البيانات');
    }
  }, []);

  if (error) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>⚠️ حدث خطأ فادح أثناء تهيئة LifeOS:</Text>
        <Text style={styles.errorSubText}>{error}</Text>
      </View>
    );
  }

  if (!isInitialized) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#3b82f6" />
        <Text style={styles.loadingText}>جاري تهيئة LifeOS وتحميل المحتوى...</Text>
        <StatusBar style="auto" />
      </View>
    );
  }

  return (
    <>
      <AppNavigator />
      <StatusBar style="light" />
    </>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f8fafc', padding: 20 },
  loadingText: { marginTop: 12, color: '#64748b', fontSize: 14 },
  errorText: { color: '#ef4444', fontSize: 16, fontWeight: 'bold', textAlign: 'center', marginBottom: 8 },
  errorSubText: { color: '#64748b', fontSize: 14, textAlign: 'center' }
});
